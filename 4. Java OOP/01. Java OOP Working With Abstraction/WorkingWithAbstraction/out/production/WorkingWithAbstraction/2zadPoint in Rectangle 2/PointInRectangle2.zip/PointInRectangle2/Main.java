package PointInRectangle2;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] coordinates = scanner.nextLine().split("\\s+");

        int bottomLeftX = Integer.parseInt(coordinates[0]);
        int bottomLeftY = Integer.parseInt(coordinates[1]);
        int topRightX = Integer.parseInt(coordinates[2]);
        int topRightY = Integer.parseInt(coordinates[3]);
        Rectangle rectangle = new Rectangle(bottomLeftX,
                bottomLeftY, topRightX,topRightY);
        int n = Integer.parseInt(scanner.nextLine());
        for (int i = 0; i < n; i++) {
            String[] pointCoordinate =
                    scanner.nextLine().split("\\s+");
            int x = Integer.parseInt(pointCoordinate[0]);
            int y = Integer.parseInt(pointCoordinate[1]);
            Point point = new Point(x,y);
            rectangle.contains(point);
        }
    }
}
