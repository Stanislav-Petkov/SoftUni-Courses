package PointInRectangle2;

public class Rectangle {

    int bottomLeftX;
    int bottomLeftY;
    int topRightX;
    int topRightY;

    public Rectangle(int bottomLeftX,
            int bottomLeftY,
            int topRightX,
            int topRightY){
        this.bottomLeftX = bottomLeftX;
        this.bottomLeftY = bottomLeftY;
        this.topRightX = topRightX;
        this.topRightY = topRightY;
    }
    public void contains(Point point){
        if(point.x >= bottomLeftX && point.x <= topRightX
        && point.y >= bottomLeftY && point.y <= topRightY){
            System.out.println("true");
            return;
        }
        System.out.println("false");;
    }
}
