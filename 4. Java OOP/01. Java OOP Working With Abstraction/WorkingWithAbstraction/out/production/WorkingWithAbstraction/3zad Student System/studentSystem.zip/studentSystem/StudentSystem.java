package studentSystem;

import java.util.HashMap;
import java.util.Map;

public class StudentSystem {
//klasa priema repository i znae kak da raboti s nego  v         this.repo = repo;
    //moje da zapisva unikalni studenti sys persistUniqueStudent
    //vrushta informaciq za uchenik po negovoto ime s  studentInformationFor
    private StudentRepository repo;

    public StudentSystem(StudentRepository repo) {
        this.repo = repo;
    }

    public String studentInformationFor(String name) {
        if (repo.containsStudentWith(name)) {
            Student student = repo.fetchBy(name);
            return student.studentInformation();
        }
        return null;
    }

    public void persistUniqueStudent(Student student) {

        if (!repo.containsStudentWith(student.getName())) {
            repo.save(student); 
        }
    }


}
