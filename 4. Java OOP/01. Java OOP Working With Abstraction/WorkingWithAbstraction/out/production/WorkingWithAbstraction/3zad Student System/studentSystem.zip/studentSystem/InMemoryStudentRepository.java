package studentSystem;

import java.sql.Struct;
import java.util.HashMap;
import java.util.Map;

public class InMemoryStudentRepository implements StudentRepository {
    private final Map<String, Student> map;// promenlivata map ne moje da bude reasignvana
    //sled kato e stanala final          this.map = new HashMap<>()

    public InMemoryStudentRepository(){
        this.map = new HashMap<>();
    }

    @Override
    public boolean containsStudentWith(String name) {
        return map.containsKey(name);
    }

    @Override
    public Student fetchBy(String name) {
        return map.get(name);
        //map.get spazva nashiq kontract
        //ot StudentRepository * @param name of the student to fetch.
        //     * @return the student with the given name if found.
        //     * null if not present.
    }

    @Override
    public void save(Student student) {
        map.put(student.getName(),student);
    }
}
//student repository koeto shte bude implementirano v ram pametta
//i kato restartiram komputerq nqma da se zapazva
// takova repository moje da se implementira stiga da otgovarq na dogovora ot interfeisa
//i da implementira metodite ot nego
