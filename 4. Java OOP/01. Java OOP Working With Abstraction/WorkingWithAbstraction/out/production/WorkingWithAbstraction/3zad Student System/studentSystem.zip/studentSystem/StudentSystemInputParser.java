package studentSystem;

public class StudentSystemInputParser {
//tozi klas razbira kak da pravi uchenici
//davame mu celiq red i klasa vrushta parsnatata komanda, endnate e suzdai mi student
    //i show dai mi imeto na studenta

    //•	“Create <studentName> <studentAge> <studentGrade>”
    public static Student createStudent(String[] args){
        String name = args[1];
        var age = Integer.parseInt(args[2]);
        var grade = Double.parseDouble(args[3]);
        return new Student(name, age, grade);

    }
}
