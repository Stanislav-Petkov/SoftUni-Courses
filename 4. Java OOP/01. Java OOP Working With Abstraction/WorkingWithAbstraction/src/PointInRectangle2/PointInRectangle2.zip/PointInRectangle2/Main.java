package PointInRectangle2;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Point bottomLeft = createPointReadingTwoIntsFrom(scanner);
        Point topRight = createPointReadingTwoIntsFrom(scanner);

        Rectangle rectangle = new Rectangle(bottomLeft,topRight);

        int numberOfPoints =  scanner.nextInt();

        for (int i = 0; i < numberOfPoints; i++) {
            Point point = createPointReadingTwoIntsFrom(scanner);
            System.out.println(rectangle.contains(point));

        }
    }
    private static Point createPointReadingTwoIntsFrom(Scanner scanner){
        int pointX = scanner.nextInt();
        int pointY =scanner.nextInt();
        return new Point(pointX,pointY); //vrushta tochka
    }
}
//
///*
//
//package PointInRectangle2;
//
//import java.util.Scanner;
//
//public class Main {
//    public static void main(String[] args) {
//        Scanner scanner = new Scanner(System.in);
//        String[] coordinates = scanner.nextLine().split("\\s+");
//
//        int bottomLeftX = Integer.parseInt(coordinates[0]);
//        int bottomLeftY = Integer.parseInt(coordinates[1]);
//        int topRightX = Integer.parseInt(coordinates[2]);
//        int topRightY = Integer.parseInt(coordinates[3]);
//        Rectangle rectangle = new Rectangle(bottomLeftX,
//                bottomLeftY, topRightX,topRightY);
//        int n = Integer.parseInt(scanner.nextLine());
//        for (int i = 0; i < n; i++) {
//            String[] pointCoordinate =
//                    scanner.nextLine().split("\\s+");
//            int x = Integer.parseInt(pointCoordinate[0]);
//            int y = Integer.parseInt(pointCoordinate[1]);
//            Point point = new Point(x,y);
//            rectangle.contains(point);
//        }
//    }
//}
//
//
//package PointInRectangle2;
//
//public class Rectangle {
//
//    int bottomLeftX;
//    int bottomLeftY;
//    int topRightX;
//    int topRightY;
//
//    public Rectangle(int bottomLeftX,
//            int bottomLeftY,
//            int topRightX,
//            int topRightY){
//        this.bottomLeftX = bottomLeftX;
//        this.bottomLeftY = bottomLeftY;
//        this.topRightX = topRightX;
//        this.topRightY = topRightY;
//    }
//    public void contains(Point point){
//        if(point.x >= bottomLeftX && point.x <= topRightX
//        && point.y >= bottomLeftY && point.y <= topRightY){
//            System.out.println("true");
//            return;
//        }
//        System.out.println("false");;
//    }
//}
//
//package PointInRectangle2;
//
//public class Point {
//    int x;
//    int y;
//    Point(int x, int y){
//        this.x = x;
//        this.y = y;
//    }
//
//}
//
// */


/*
package PointInRectangle2;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int bootomLeftX = scanner.nextInt();
        int bootomLeftY = scanner.nextInt();
        int topRightX = scanner.nextInt();
        int topRightY = scanner.nextInt();
        Rectangle rectangle = new Rectangle(
                new Point(bootomLeftX,bootomLeftY),
                new Point(topRightX,topRightY)
        );
        int numberOfPoints =  scanner.nextInt();
        for (int i = 0; i < numberOfPoints; i++) {
            int pointX = scanner.nextInt();
            int pointY = scanner.nextInt();
            Point point = new Point(pointX,pointY);
            System.out.println(rectangle.contains(point));

        }
    }
}

package PointInRectangle2;

public class Rectangle {

    private Point bottomLeft;
    private Point topRight;

    public Rectangle(Point bottomLeft, Point topRight){
        this.bottomLeft = bottomLeft;
        this.topRight = topRight;
    }

    public boolean contains(Point point){
        boolean withinX = bottomLeft.getX() <= point.getX()
                && topRight.getX() >= point.getX();
        boolean withinY = bottomLeft.getY() <= point.getY()
                && topRight.getY() >= point.getY();
        return withinX && withinY;
    }

    public static void main(String[] args) {
        Point bottomLeft = new Point(0,0);
        Point topRight = new Point(2,2);
        Rectangle rectangle = new Rectangle(bottomLeft,topRight);

        System.out.println(rectangle.contains(new Point(1,1)));
        System.out.println(rectangle.contains(new Point(2,3)));
    }
}

package PointInRectangle2;

public class Point {
    int x;
    int y;
    Point(int x, int y){
        this.x = x;
        this.y = y;
    }

    public int getX(){
        return x;
    }
    public int getY(){
        return y;
    }
}
//immutable klas e takuv koito nqma setteri i  parametrite
//mu ne mogat da budat promenqni otvun

 */