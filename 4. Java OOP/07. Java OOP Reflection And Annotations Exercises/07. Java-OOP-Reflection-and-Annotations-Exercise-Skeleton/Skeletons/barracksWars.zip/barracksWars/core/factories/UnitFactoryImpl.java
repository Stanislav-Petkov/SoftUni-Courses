package barracksWars.core.factories;

import barracksWars.interfaces.Unit;
import barracksWars.interfaces.UnitFactory;
import barracksWars.models.units.*;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.List;

public class UnitFactoryImpl implements UnitFactory {

	private static final String UNITS_PACKAGE_NAME =
			"barracksWars.models.units.";

	@Override
	public Unit createUnit(String unitType) { // } throws ExecutionControl.NotImplementedException {
		// TODO: implement for problem 3
		try {
			Class<?> classes = Class.forName(UNITS_PACKAGE_NAME + unitType);
			Constructor<?> ctor = classes.getDeclaredConstructor();
			Object obj = ctor.newInstance();
			if(obj instanceof Unit){
				return (Unit) obj;
			}
		} catch (ClassNotFoundException
				| NoSuchMethodException
				| IllegalAccessException
				| InstantiationException
				| InvocationTargetException e) {
			e.printStackTrace();
		}

		return null;
	}
}

/*
	@Override
	public Unit createUnit(String unitType){ // } throws ExecutionControl.NotImplementedException {

		//throw new ExecutionControl.NotImplementedException("message");
		Unit unit = null;
		if(unitType.equals("Swordsman")){
			unit = new Swordsman();
		}else if(unitType.equals("Archer")){
			unit = new Archer();
		}else if(unitType.equals("Pikeman")){
			unit = new Pikeman();
		}else if(unitType.equals("Horseman")){
			unit = new Horseman();
		}else if(unitType.equals("Gunner")){
			unit = new Gunner();
		}

		return unit;
	}
}
 */