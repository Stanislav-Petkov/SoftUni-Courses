package barracksWars.core.commands;

import barracksWars.interfaces.Inject;
import barracksWars.interfaces.Repository;
import barracksWars.interfaces.UnitFactory;

public class RetireCommand extends Command {
    @Inject
    private String[] data;
    @Inject
    private Repository repository;

    private int ignored;

    public RetireCommand(){
    }

    @Override
    public String execute() {
        String unitType = this.data[1];
        try {
            this.repository.removeUnit(unitType);
            return unitType + " retired!";
        }catch (IllegalArgumentException e){
            return e.getMessage();
        }
    }
}
