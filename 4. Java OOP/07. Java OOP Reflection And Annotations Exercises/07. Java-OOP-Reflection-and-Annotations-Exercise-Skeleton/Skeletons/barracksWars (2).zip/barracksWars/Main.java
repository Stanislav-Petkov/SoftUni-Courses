package barracksWars;

import barracksWars.core.CommandInterpreterImpl;
import barracksWars.interfaces.Repository;
import barracksWars.interfaces.Runnable;
import barracksWars.interfaces.UnitFactory;
import barracksWars.core.Engine;
import barracksWars.core.factories.UnitFactoryImpl;
import barracksWars.data.UnitRepository;

public class Main {

    public static void main(String[] args) {

        //tezi 2 obekta  unitFactory,repository se suzdavat 1 put  kakto i CommandInterpreterImpl
        UnitFactory unitFactory = new UnitFactoryImpl();
        Repository repository = new UnitRepository();

        //tezi 2 obekta sa spodeleni mejdu vsichki obekti koito trqbda da imat dostup do tezi instancii  unitFactory,repository

        Runnable engine = new Engine(new CommandInterpreterImpl(unitFactory, repository));
        engine.run();
    }
}
