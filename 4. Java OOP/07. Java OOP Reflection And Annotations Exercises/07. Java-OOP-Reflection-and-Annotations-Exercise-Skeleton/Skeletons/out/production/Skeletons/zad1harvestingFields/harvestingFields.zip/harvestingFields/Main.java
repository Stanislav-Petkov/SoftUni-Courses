
package harvestingFields;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String input = scanner.nextLine();

        Field[] fields = RichSoilLand.class.getDeclaredFields();
        StringBuilder builder = new StringBuilder();
        while (!input.equals("HARVEST")) {


            for (Field field : fields) {
                int modifier = field.getModifiers();
                String modifierAsString = Modifier.toString(modifier);
                if (modifierAsString.equals(input) || input.equals("all")) {
                    builder.append(String.format("%s %s %s%n",
                            modifierAsString,field.getType().getSimpleName(), field.getName()));
                }
            }

            input = scanner.nextLine();
        }
        System.out.println(builder.toString());
    }
}

/*

package harvestingFields;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String input = scanner.nextLine();

        while (!input.equals("HARVEST")) {

            Field[] fields = RichSoilLand.class.getDeclaredFields();

            for (Field field : fields) {
                int modifier = field.getModifiers();
                String modifierAsString = Modifier.toString(modifier);
                if (modifierAsString.equals(input) || input.equals("all")) {
                    System.out.println(String.format("%s %s %s",
                            modifierAsString,field.getType().getSimpleName(), field.getName()));
                }
            }

            input = scanner.nextLine();
        }
    }
}


 */
/*

package harvestingFields;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String input = scanner.nextLine();

        while (!input.equals("HARVEST")) {
            Field[] fields = RichSoilLand.class.getDeclaredFields();
            if(input.equals("private")){
                for(Field field : fields){
                    int modifier = field.getModifiers();
                    if(modifier == 2) {
                        System.out.println(
                                String.format("private %s %s",
                                        field.getType().getSimpleName(),field.getName()));
                    }
                }
            }else if(input.equals("protected")){
                for(Field field : fields){
                    int modifier = field.getModifiers();
                    if(modifier == 4) {
                        System.out.println(
                                String.format("protected %s %s",
                                        field.getType().getSimpleName(),field.getName()));
                    }
                }
            }else if(input.equals("public")){
                for(Field field : fields){
                    int modifier = field.getModifiers();
                    if(modifier == 1) {
                        System.out.println(
                                String.format("public %s %s",
                                        field.getType().getSimpleName(),field.getName()));
                    }
                }
            }else{
                for(Field field : fields){
                    int modifier = field.getModifiers();
                    String modifierAsString = Modifier.toString(modifier);
                    System.out.println(String.format("%s %s %s",
                                        modifierAsString,field.getType().getSimpleName(),field.getName()));

                }
            }
            input = scanner.nextLine();
        }
    }
}

 */
/*
package harvestingFields;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        Class<RichSoilLand> clazz = RichSoilLand.class;
        Field[] fields = clazz.getDeclaredFields();

        String input = scanner.nextLine();

        while (!input.equals("HARVEST")) {
            if (input.equals("protected")) {
                printProtectedFields(fields);
            } else if (input.equals("private")) {
                printPrivateFields(fields);
            } else if (input.equals("public")) {
                printPublicFields(fields);
            } else if (input.equals("all")) {
                printAllFields(fields);
            }

            input = scanner.nextLine();

        }
    }


    private static void printProtectedFields(Field[] fields) {
        for (Field field : fields) {
            int modifier = field.getModifiers();
            if (Modifier.isProtected(modifier)) {
                System.out.println(
                        String.format("%s %s %s", Modifier.toString(field.getModifiers()),
                                field.getType().getSimpleName(), field.getName()));
            }
        }
    }

    private static void printPrivateFields(Field[] fields) {
        for (Field field : fields) {
            int modifier = field.getModifiers();
            if (Modifier.isPrivate(modifier)) {
                System.out.println(
                        String.format("%s %s %s", Modifier.toString(field.getModifiers()),
                                field.getType().getSimpleName(), field.getName()));
            }
        }
    }

    private static void printPublicFields(Field[] fields) {
        for (Field field : fields) {
            int modifier = field.getModifiers();
            if (Modifier.isPublic(modifier)) {
                System.out.println(
                        String.format("%s %s %s", Modifier.toString(field.getModifiers()),
                                field.getType().getSimpleName(), field.getName()));
            }
        }
    }

    private static void printAllFields(Field[] fields) {
        for (Field field : fields) {
            System.out.println(
                    String.format("%s %s %s", Modifier.toString(field.getModifiers()),
                            field.getType().getSimpleName(), field.getName()));

        }
    }
}

 */