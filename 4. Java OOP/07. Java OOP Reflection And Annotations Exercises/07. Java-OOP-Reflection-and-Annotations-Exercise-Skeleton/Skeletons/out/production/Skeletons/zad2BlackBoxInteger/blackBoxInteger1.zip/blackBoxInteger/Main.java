package blackBoxInteger;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Map;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) throws Exception {
        Scanner scanner = new Scanner(System.in);

        BlackBoxInt blackBoxInt;
        try {
            Constructor<?> ctor = BlackBoxInt.class.getDeclaredConstructor();  // vzima construktor koito ne priema parametri
            ctor.setAccessible(true);
            Object obj = ctor.newInstance();
            assert obj instanceof BlackBoxInt;
            blackBoxInt = (BlackBoxInt) obj;  // blackBoxInt e instanciqta na klasa s prazniq constuktor
            //newInstance priema obektite s koito trqbva da bude inicializiran

        } catch (NoSuchMethodException e) {
            e.printStackTrace();
            throw new Exception(e);
        }

        //imeto na metoda i samiq metod
        Map<String, Method> methodByName =
                Arrays.stream(blackBoxInt.getClass().getDeclaredMethods())
                        .peek(m -> m.setAccessible(true))    //pravi vseki metod accessible
                        .collect(Collectors.toMap(m -> m.getName(), m -> m));
        //imeto na metoda ,i samiq metod
        //pravi stream po metodite v klasa i gi zapisva v map


        String line = scanner.nextLine();
        while (!line.equals("END")) {
            String[] tokens = line.split("_");
            String command = tokens[0];
            int param = Integer.parseInt(tokens[1]);

            Method method = methodByName.get(command);
            method.invoke(blackBoxInt,param);

            Field innerValue = BlackBoxInt.class.getDeclaredField("innerValue");

            innerValue.setAccessible(true);

            int value = (int) innerValue.get(blackBoxInt);

            System.out.println(value);

            line = scanner.nextLine();
        }

    }
}

/*

            Constructor<?> ctor = BlackBoxInt.class.getDeclaredConstructor(int.class);
            //dostupva konstruktor koito priema int



        //Constructor<?>[] declaredConstructors = BlackBoxInt.class.getDeclaredConstructors();
// vzima vsichki konstruktori

 */

/*
package blackBoxInteger;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws NoSuchMethodException, InvocationTargetException,
            IllegalAccessException, InstantiationException, ClassNotFoundException, NoSuchFieldException {

        Scanner scanner = new Scanner(System.in);

        Class<BlackBoxInt> clazz = BlackBoxInt.class;
        Constructor<BlackBoxInt> ctor = clazz.getDeclaredConstructor();
        ctor.setAccessible(true);
        BlackBoxInt x = ctor.newInstance();

        Field field = clazz.getDeclaredField("innerValue");
        field.setAccessible(true);
        Method[] methods = clazz.getDeclaredMethods();
        String input = scanner.nextLine();
        while (!input.equals("END")){
            String[] tokens = input.split("_");
            String command = tokens[0];
            int num = Integer.parseInt(tokens[1]);
            for(Method method : methods){
                method.setAccessible(true);
                if(method.getName().equals(command)){

                    method.invoke(x, num);
                    System.out.println(field.get(x));
                }
            }

            input = scanner.nextLine();
        }
    }
}

 */