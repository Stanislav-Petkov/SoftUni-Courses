package blackBoxInteger;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws NoSuchMethodException, InvocationTargetException,
            IllegalAccessException, InstantiationException, ClassNotFoundException, NoSuchFieldException {

        Scanner scanner = new Scanner(System.in);

        Class<BlackBoxInt> clazz = BlackBoxInt.class;
        Constructor<BlackBoxInt> ctor = clazz.getDeclaredConstructor();
        ctor.setAccessible(true);
        BlackBoxInt x = ctor.newInstance();

        Field field = clazz.getDeclaredField("innerValue");
        field.setAccessible(true);
        Method[] methods = clazz.getDeclaredMethods();
        String input = scanner.nextLine();
        while (!input.equals("END")){
            String[] tokens = input.split("_");
            String command = tokens[0];
            int num = Integer.parseInt(tokens[1]);
            for(Method method : methods){
                method.setAccessible(true);
                if(method.getName().equals(command)){

                    method.invoke(x, num);
                    System.out.println(field.get(x));
                   // int value = field.getInt(clazz);
                    //System.out.println(value);

                }
            }

            input = scanner.nextLine();
        }
    }
}
