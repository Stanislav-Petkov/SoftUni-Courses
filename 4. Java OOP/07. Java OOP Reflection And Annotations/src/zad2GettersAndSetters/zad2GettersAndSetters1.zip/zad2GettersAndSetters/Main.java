package zad2GettersAndSetters;

import java.lang.reflect.Method;
import java.sql.Ref;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        Class clazz = Reflection.class;

        Method[] methods = clazz.getDeclaredMethods();

        Arrays.stream(methods)
                .filter(method -> method.getName().startsWith("get"))
                .sorted(Comparator.comparing(Method::getName))
                .forEach(method -> System.out.println(
                        String.format("%s will return class %s",
                                method.getName(),method.getReturnType().getName())
                ));



        Arrays.stream(methods)
                .filter(method -> method.getName().startsWith("set"))
                .filter(method -> method.getParameterTypes().length == 1)
                .sorted(Comparator.comparing(Method::getName))
                .forEach(method -> System.out.println(method.getName() +
                        " and will set field of class " + method.getParameterTypes()[0].getName()));



    }
}

/*
//100
package zad2GettersAndSetters;

import java.lang.reflect.Method;
import java.sql.Ref;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        Class clazz = Reflection.class;

        Method[] getters = Arrays.stream(clazz.getDeclaredMethods())
                .sorted((a,b) -> a.getName().compareTo(b.getName()))
                .toArray(Method[]::new);

        for(Method method : getters){
            if(method.getName().startsWith("get")) {
                System.out.println(String.format( method.getName() +
                        " will return class " + method.getReturnType().getName()));
            }
        }


        Method[] setters = Arrays.stream(clazz.getDeclaredMethods())
                .sorted((a,b) -> a.getName().compareTo(b.getName()))
                .toArray(Method[]::new);

        for(Method method : setters){
            if(method.getName().startsWith("set")) {
                System.out.print(method.getName() + " and will set field of class " );
                        Arrays.stream(method.getParameterTypes())
                .forEach(e -> System.out.println(e.getName()));

            }
        }
    }
}

 */
