import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

public class Main {

    public static void main(String[] args) throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException {
        Class<Reflection> clazz = Reflection.class;
        System.out.println(clazz);

        Class<? super Reflection> superClazz = clazz.getSuperclass();
        System.out.println(superClazz);

        Class<?>[] interfaces = clazz.getInterfaces();
        for (Class<?> anInterface : interfaces) {
            System.out.println(anInterface);
        }


        Constructor<Reflection> ctor = clazz.getDeclaredConstructor();
        ctor.setAccessible(true);
        Reflection x = ctor.newInstance();
        System.out.println(x);
        //Reflection reflection = new Reflection();
    }
}

/*
 Constructor<?> ctors = clazz.getDeclaredConstructor(String.class,String.class,String.class);
        System.out.println(ctors.newInstance("Foo","Bar","Zar"));

       Reflection reflection = new Reflection(); //tova e  kato dolnoto
        System.out.println(reflection);

        Constructor<?> ctor = clazz.getDeclaredConstructor();
        System.out.println(ctor.newInstance());


  Constructor<?>[] ctors = clazz.getDeclaredConstructors();
        for (Constructor<?> ctor : ctors) {
            System.out.println(ctor);
        }
 */