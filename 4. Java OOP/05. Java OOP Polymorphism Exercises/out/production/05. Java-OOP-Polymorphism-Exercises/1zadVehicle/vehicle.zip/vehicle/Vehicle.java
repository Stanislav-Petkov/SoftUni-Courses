package vehicle;

public interface Vehicle {
    abstract double getQuantity();
    abstract double getConsumption();

    void canItDriveThisMuch(double distance);

    void refuel(double liters);

}
