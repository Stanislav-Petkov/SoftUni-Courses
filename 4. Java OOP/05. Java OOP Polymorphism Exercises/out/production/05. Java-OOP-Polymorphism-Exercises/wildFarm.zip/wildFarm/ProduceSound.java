package wildFarm;

public interface ProduceSound {
    void makeSound();
}
