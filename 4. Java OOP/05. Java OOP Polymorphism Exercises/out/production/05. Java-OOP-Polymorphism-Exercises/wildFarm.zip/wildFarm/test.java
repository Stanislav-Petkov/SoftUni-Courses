package wildFarm;

public class test {
    public static void main(String[] args) {
        double a = 3.4;
        System.out.println(a);
    }
}
