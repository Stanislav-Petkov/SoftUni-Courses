package calculator5;

public class Extensions {
    public static InputInterpreter buildInterpreter(CalculationEngine engine) {

        System.out.println();
        InputInterpreter inputInterpreter = new InputInterpreter(engine);

    //    CalculationEngine engine
        //ot engine vrushta InputInterpreter
        return inputInterpreter;
    }
}
