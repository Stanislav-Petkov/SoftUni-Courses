package aquarium.models.aquariums;

import aquarium.models.decorations.Decoration;
import aquarium.models.fish.Fish;

import java.util.LinkedList;

public class SaltwaterAquarium extends BaseAquarium {
    private static final int CAPACITY = 25;
    public SaltwaterAquarium(String name) {
        super(name, CAPACITY);
    }
}




/*
 @Override
    public String getInfo() {
        StringBuilder builder = new StringBuilder();
        builder.append(this.getName()).append(" (").append(this.getClass().getSimpleName()).append("):");
        builder.append(System.lineSeparator());
        builder.append("Fish: ");

        LinkedList<Fish> fish = (LinkedList<Fish>) this.getFish();

        String fishNames = "";
        if (fish.isEmpty()) {
            fishNames = "none";
        } else {
            for (Fish fish1 : fish) {
                fishNames += fish1.getName() + " ";
            }
        }
        builder.append(fishNames);
        builder.append(System.lineSeparator());
        builder.append("Decorations: ").append(this.getDecorations().size());
        builder.append(System.lineSeparator());
        int sumOfComfort = 0;
        for (Decoration decoration : this.getDecorations()) {
            sumOfComfort +=  decoration.getComfort();
        }
        builder.append("Comfort: ").append(sumOfComfort);
        return builder.toString();
    }
 */