package aquarium.common;

import aquarium.core.Controller;
import aquarium.models.aquariums.Aquarium;
import aquarium.models.aquariums.FreshwaterAquarium;
import aquarium.models.aquariums.SaltwaterAquarium;
import aquarium.models.decorations.Decoration;
import aquarium.models.decorations.Ornament;
import aquarium.models.decorations.Plant;
import aquarium.models.fish.Fish;
import aquarium.models.fish.FreshwaterFish;
import aquarium.models.fish.SaltwaterFish;
import aquarium.repositories.DecorationRepository;

import static aquarium.common.ExceptionMessages.*;
import static aquarium.common.ConstantMessages.*;
import java.util.Collection;
import java.util.LinkedList;

public class ControllerImpl implements Controller {

    private DecorationRepository decorations;
    private Collection<Aquarium> aquariums;

    public ControllerImpl(){
        this.decorations = new DecorationRepository();
        this.aquariums = new LinkedList<>();
    }

    @Override
    public String addAquarium(String aquariumType, String aquariumName) {

        Aquarium aquarium = null;
        if(aquariumType.equals("FreshwaterAquarium")){
            aquarium = new FreshwaterAquarium(aquariumName);
        }else if(aquariumType.equals("SaltwaterAquarium")){
            aquarium = new SaltwaterAquarium(aquariumName);
        }else {
            throw new IllegalArgumentException(INVALID_AQUARIUM_TYPE);
        }
        this.aquariums.add(aquarium);
        return String.format(SUCCESSFULLY_ADDED_AQUARIUM_TYPE,aquariumType);
    }

    @Override
    public String addDecoration(String type) {
        Decoration decoration = null;
        if(type.equals("Ornament")){
            decoration = new Ornament();
        }else if(type.equals("Plant")){
            decoration = new Plant();
        }else {
            throw new IllegalArgumentException(INVALID_DECORATION_TYPE);
        }
        this.decorations.add(decoration);
        return String.format(SUCCESSFULLY_ADDED_DECORATION_TYPE,type);
    }

    @Override
    public String insertDecoration(String aquariumName, String decorationType) {
        for (Aquarium aquarium : this.aquariums) {
            if(aquarium.getName().equals(aquariumName)){
                Decoration decoration = this.decorations.findByType(decorationType);
                if(decoration != null){
                    aquarium.addDecoration(decoration);
                }else if(decoration == null){
                    throw new IllegalArgumentException(String.format(NO_DECORATION_FOUND
                            ,decorationType));
                }
            }
        }
        return String.format(SUCCESSFULLY_ADDED_DECORATION_IN_AQUARIUM
                ,decorationType,aquariumName);
    }

    @Override
    public String addFish(String aquariumName, String fishType, String fishName, String fishSpecies, double price) {
        for (Aquarium aquarium : this.aquariums) {
            if(aquarium.getName().equals(aquariumName)){

                Fish fish=null;
                if(fishType.equals("FreshwaterFish")){
                    if(aquarium.getClass().getSimpleName().equals("FreshwaterAquarium")){
                        fish = new FreshwaterFish(fishName,fishSpecies,price);
                        //aquarium.addFish(fish); //checks the capacity inside and throws Exception
                        try {
                            aquarium.addFish(fish);
                            return String.format(SUCCESSFULLY_ADDED_FISH_IN_AQUARIUM
                                    ,fishType,aquariumName);
                        }catch (Exception ex){
                            return ex.getMessage();
                        }
                    }else {
                        return WATER_NOT_SUITABLE;
                    }
                }else if(fishType.equals("SaltwaterFish")){
                    if(aquarium.getClass().getSimpleName().equals("SaltwaterAquarium")){
                        fish = new SaltwaterFish(fishName,fishSpecies,price);
                        try {
                            aquarium.addFish(fish);
                            return String.format(SUCCESSFULLY_ADDED_FISH_IN_AQUARIUM
                                    ,fishType,aquariumName);
                        }catch (Exception ex){
                            return ex.getMessage();
                        }
                    }else {
                        return WATER_NOT_SUITABLE;
                    }
                }else {
                    throw new IllegalArgumentException(INVALID_FISH_TYPE);
                }
            }
        }
        return null;
    }

    @Override
    public String feedFish(String aquariumName) {
        int fedCount=0;
        for (Aquarium aquarium : this.aquariums) {
            if(aquarium.getName().equals(aquariumName)){
                aquarium.feed();
                fedCount = aquarium.getFish().size();
                return String.format(FISH_FED,fedCount);
            }
        }
        return null;
    }

    @Override
    public String calculateValue(String aquariumName) {
        double fishSum = 0;
        double decorationSum = 0;

        for (Aquarium aquarium : this.aquariums) {
            if(aquariumName.equals(aquarium.getName())){
                for (Fish fish : aquarium.getFish()) {
                    fishSum += fish.getPrice();
                }
                for(Decoration decoration : aquarium.getDecorations()){
                    decorationSum += decoration.getPrice();
                }
            }
        }

        return String.format(VALUE_AQUARIUM,aquariumName, (fishSum + decorationSum));
    }

    @Override
    public String report() {
        StringBuilder builder = new StringBuilder();
        for (Aquarium aquarium : this.aquariums) {
            builder.append(aquarium.getInfo());
            builder.append(System.lineSeparator());
        }
        return builder.toString();
    }
}
