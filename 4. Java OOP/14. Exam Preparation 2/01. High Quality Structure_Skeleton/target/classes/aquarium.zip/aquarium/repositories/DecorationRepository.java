package aquarium.repositories;

import aquarium.models.decorations.Decoration;

import java.util.Collection;
import java.util.LinkedList;

public class DecorationRepository implements Repository {

    private Collection<Decoration> decorations;

    public DecorationRepository(){
        this.decorations = new LinkedList<>();
    }

    @Override
    public void add(Decoration decoration) {
        this.decorations.add(decoration);
    }

    @Override
    public boolean remove(Decoration decoration) {
        boolean wasRemoved = false;
        for (Decoration currDecoration : decorations) {
            if (decoration.equals(currDecoration)) {
                this.decorations.remove(decoration);
                wasRemoved = true;
                //return wasRemoved;
                break;
            }
        }
        return wasRemoved;
    }

    @Override
    public Decoration findByType(String type) {
        for (Decoration decoration : this.decorations) {
            if (decoration.getClass().getSimpleName().equals(type)) {
                this.decorations.remove(decoration);
                return decoration;
            }
        }

        return null;
    }
}
