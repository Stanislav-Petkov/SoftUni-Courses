package aquarium;

import org.junit.Assert;
import org.junit.Test;
import static org.junit.Assert.*;
public class AquariumTests {
    @Test
    public void constructorShouldCreateValidInstance(){
        Aquarium aquarium = new Aquarium("Word",5);

        String expectedName = "Word";
        int expectedCapacity = 5;

        String actualName = aquarium.getName();
        int actualCapacity = aquarium.getCapacity();
        assertEquals(expectedName,actualName);
        assertEquals(expectedCapacity,actualCapacity);
    }

    @Test(expected = IllegalArgumentException.class)
    public void constructorShouldCreateInValidInstance(){
        Aquarium aquarium = new Aquarium("Word",-5);

       
    }
    @Test
    public void fishConstructorShouldCreateValidFish(){
        Fish fish = new Fish("Nemo");
        String expectedFish = "Nemo";
        String actualFish = fish.getName();
        assertEquals(expectedFish,actualFish);
    }
    @Test
    public void validateAddMethodValid(){
        Aquarium aquarium = new Aquarium("Word",5);
        Fish fish = new Fish("Nemo");

        aquarium.add(fish);
        int expectedSize = 1;
        int actualSize = aquarium.getCount();
        assertEquals(expectedSize,actualSize);
    }
    @Test(expected = IllegalArgumentException.class)
    public void validateAddMethodInvalid(){
        Aquarium aquarium = new Aquarium("Word",1);
        Fish fish = new Fish("Nemo");
        Fish fish2 = new Fish("Nemo2");

        aquarium.add(fish);
        aquarium.add(fish2);
    }

    @Test(expected = IllegalArgumentException.class)
    public void validateRemoveMethodInvalid(){
        Aquarium aquarium = new Aquarium("Word",1);
        Fish fish = new Fish("Nemo");
        aquarium.add(fish);
        aquarium.remove("Nemo2");

    }
    @Test
    public void validateRemoveMethodValid(){
        Aquarium aquarium = new Aquarium("Word",1);
        Fish fish = new Fish("Nemo");
        aquarium.add(fish);
        aquarium.remove("Nemo");
        int expectedSize = 0;
        int actualSize = aquarium.getCount();
        assertEquals(expectedSize, actualSize);
    }

    @Test
    public void validateSellFishMethodValid(){
        Aquarium aquarium = new Aquarium("Word",2);
        Fish fish = new Fish("Nemo");
        aquarium.add(fish);
        Fish expectedFish = aquarium.sellFish("Nemo");
        assertFalse(expectedFish.isAvailable());
    }
    @Test(expected = IllegalArgumentException.class)
    public void validateSellFishMethodInvalid(){
        Aquarium aquarium = new Aquarium("Word",2);
        Fish fish = new Fish("Nemo");
        aquarium.add(fish);
        Fish expectedFish = aquarium.sellFish("Nemo2");
    }
    @Test
    public void testReportMethod(){
        Aquarium aquarium = new Aquarium("Word",5);
        aquarium.add(new Fish("Nemo"));
        String  actual = "Fish available at Word: Nemo";
        String expected = aquarium.report() ;
        assertEquals(actual,expected);
    }
}





/*
 @Test
    public void testCorrectNameAndCapacity(){
        Aquarium aquarium = new Aquarium("aqua", 10);
    }

    @Test(expected = NullPointerException.class)
    public void testEmptyInvalidName(){
        Aquarium aquarium = new Aquarium("", 10);
    }

    @Test(expected = NullPointerException.class)
    public void testNullInvalidName(){
        Aquarium aquarium = new Aquarium(null, 10);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testInvalidCapacity(){
        Aquarium aquarium = new Aquarium("null", -10);
    }

    @Test
    public void testAdd(){
        Aquarium aquarium = new Aquarium("Aqua", 10);
        aquarium.add(new Fish("fish1"));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testMoreThanCapacityAdd(){
        Aquarium aquarium = new Aquarium("Aqua", 2);
        aquarium.add(new Fish("fish1"));
        aquarium.add(new Fish("fish1"));
        aquarium.add(new Fish("fish1"));
    }

    @Test
    public void testValidCapacityAdd(){
        Aquarium aquarium = new Aquarium("Aqua", 2);
        aquarium.add(new Fish("fish1"));
        aquarium.add(new Fish("fish1"));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testInvalidRemove(){
        Aquarium aquarium = new Aquarium("Aqua", 2);
        aquarium.add(new Fish("fish1"));
        aquarium.add(new Fish("fish2"));
        aquarium.remove("Fish3");
    }

    @Test
    public void testValidRemove(){
        Aquarium aquarium = new Aquarium("Aqua", 2);
        aquarium.add(new Fish("fish1"));
        aquarium.add(new Fish("fish2"));
        aquarium.remove("fish2");
    }

    @Test
    public void testValidSelfFish() {
        Aquarium aquarium = new Aquarium("Aqua", 2);
        aquarium.add(new Fish("fish1"));
        aquarium.add(new Fish("fish2"));
        Fish fish2 = aquarium.sellFish("fish2");
        assertEquals(fish2,aquarium.sellFish("fish2"));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testInvalidSelfFish() {
        Aquarium aquarium = new Aquarium("Aqua", 2);
        aquarium.add(new Fish("fish1"));
        aquarium.add(new Fish("fish2"));
        Fish fish2 = aquarium.sellFish("fish23");
    }

    @Test
    public void testValidSelfFishIsAvailable() {
        Aquarium aquarium = new Aquarium("Aqua", 2);
        aquarium.add(new Fish("fish1"));
        aquarium.add(new Fish("fish2"));
        Fish fish2 = aquarium.sellFish("fish2");
        assertEquals(fish2,aquarium.sellFish("fish2"));
        assertFalse(fish2.isAvailable());
    }

    @Test
    public void testReport(){
        Fish f = new Fish("name");
        Fish f1 = new Fish("name1");
        Fish f2 = new Fish("name2");
        Aquarium aquarium = new Aquarium("aqua", 10);

        aquarium.add(f);
        aquarium.add(f1);
        aquarium.add(f2);
        aquarium.remove("name2");
        assertEquals("Fish available at aqua: name, name1" ,aquarium.report());
    }
 */