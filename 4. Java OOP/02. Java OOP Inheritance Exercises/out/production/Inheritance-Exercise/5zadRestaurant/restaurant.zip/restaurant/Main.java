package restaurant;

import java.math.BigDecimal;

public class Main {
    public static void main(String[] args) {

    }
}


/*
  BigDecimal price = new BigDecimal(22);
        Product coffee = new Product("coff",price);
        System.out.println(coffee.getName());
        System.out.println(coffee.getPrice());
        Cake cake = new Cake("coff",price,33,11);
        System.out.println(cake.CAKE_CALORIES);
        System.out.println(cake.CAKE_GRAMS);
        System.out.println(cake.getCallories());
        System.out.println(cake.getName());
        System.out.println(cake.getPrice());
        System.out.println(cake.getGrams());
 */
/*
BigDecimal price = new BigDecimal(22);
        Coffee coffee = new Coffee("coff",price,21112);
        System.out.println(coffee.COFFEE_PRICE);
 */