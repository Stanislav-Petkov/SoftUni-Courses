package Animals;

public class Animal {
    String name;
    int age;
    String gender;

    public Animal(String name,int age, String gender){
        this.name = name;
        this.age = age;
        this.gender = gender;
    }
    public String produceSound(){
       return  "animal sound";
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getGender() {
        return gender;
    }
    public String toString(){
        return String.format("%s%n%s %d %s%n%s",this.getClass().getSimpleName()
                ,this.name,this.age,this.gender,this.produceSound());
    }
}
/*
expected: 'Tomcat\r\nTomcat 12 Male\r\nMEOW')!
expected:<Tomcat[ \r\nTomcat 12 Male ]\r\nMEOW>
 but was:<Tomcat[\r\nTomcat 12 Male]\r\...
 */