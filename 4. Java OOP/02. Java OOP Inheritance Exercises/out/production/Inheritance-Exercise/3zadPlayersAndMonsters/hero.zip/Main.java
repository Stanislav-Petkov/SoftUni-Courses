import hero.Elf;

public class Main {
    public static void main(String[] args) {
        Elf elf = new Elf("elfser",15);
        System.out.println(elf);
    }
}
