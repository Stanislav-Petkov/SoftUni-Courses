package needForSpeed;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;

public class Main {
    public static void main(String[] args) {

        Car car = new Car(10, 9);
        car.drive(3);
//        Vehicle vehicle = new Vehicle(10.0,200);
//        vehicle.drive(10);
//        System.out.println(vehicle.getFuel());
//        System.out.println(vehicle.getFuelConsumption());
    }
}
/*
import org.junit.Assert;
import org.junit.Test;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Arrays;

public class T04_TestSportCarInstance {
    private static final String METHOD_INCORRECT_RETURN_VALUE = "'%s.%s' returns invalid data (actual: '%s'; expected: '%s')!";

    @Test
    public void validateInstance() {
        // Arrange
        Object[] vehicleArgs = new Object[]{10.0, 200};
        Class<?> vehicleClass = getType("SportCar");
        Object vehicleObject = createObjectInstance(vehicleClass, vehicleArgs);

        // Act
        // Invoke methods
        getMethodValue(vehicleObject, vehicleClass, "drive", new Object[]{1}, double.class);
        Object actualFuel = getMethodValue(vehicleObject, vehicleClass, "getFuel", null);
        Object actualFuelConsumption = getMethodValue(vehicleObject, vehicleClass, "getFuelConsumption", null);
        Object actualHorsePower = getMethodValue(vehicleObject, vehicleClass, "getHorsePower", null);

        // Assert
        double expectedFuel = 0;
        double expectedFuelConsumption = 10;
        int expectedHorsePower = 200;

        String fuelMessage = String.format(METHOD_INCORRECT_RETURN_VALUE, vehicleClass.getName(), "getFuel", actualFuel, expectedFuel);
        Assert.assertEquals(fuelMessage, actualFuel, expectedFuel);

        String fuelConsumptionMessage = String.format(METHOD_INCORRECT_RETURN_VALUE, vehicleClass.getName(), "getFuelConsumption", actualFuelConsumption, expectedFuelConsumption);
        Assert.assertEquals(fuelConsumptionMessage, actualFuelConsumption, expectedFuelConsumption);

        String horsePowerMessage = String.format(METHOD_INCORRECT_RETURN_VALUE, vehicleClass.getName(), "getHorsePower", actualHorsePower, expectedHorsePower);
        Assert.assertEquals(horsePowerMessage, actualHorsePower, expectedHorsePower);
    }

    private Object getMethodValue(Object object, Class<?> clazz, String methodName, Object[] methodArgs, Class<?>... parameterTypes) {
        Method method = getMethod(clazz, methodName, parameterTypes);

        Object methodValue = null;
        if (method != null) {
            try {
                methodValue = method.invoke(object, methodArgs);
            } catch (IllegalAccessException e) {
            } catch (InvocationTargetException e) {
            }
        }

        return methodValue;
    }

    private Object createObjectInstance(Class<?> clazz, Object[] arguments) {
        Class<?>[] argumentTypes = Arrays.stream(arguments).map(Object::getClass).toArray(Class[]::new);

        Constructor<?> ctor = null;
        try {
            ctor = clazz.getDeclaredConstructor(argumentTypes);
        } catch (NoSuchMethodException e) {
            mapIntegerToInt(argumentTypes);
            mapDoubleToPrimitiveDouble(argumentTypes);

            try {
                ctor = clazz.getDeclaredConstructor(argumentTypes);
            } catch (NoSuchMethodException ex) {
            }
        }

        Object obj = null;

        if (ctor != null) {
            try {
                obj = ctor.newInstance(arguments);
            } catch (InstantiationException e) {
                e.printStackTrace();
            } catch (IllegalAccessException e) {
            } catch (InvocationTargetException e) {
            }
        }

        return obj;
    }

    private void mapIntegerToInt(Class<?>[] types) {
        for (int i = 0; i < types.length; i++) {
            if (types[i].getName().equals(Integer.class.getName())) {
                types[i] = int.class;
            }
        }
    }

    private void mapDoubleToPrimitiveDouble(Class<?>[] types) {
        for (int i = 0; i < types.length; i++) {
            if (types[i].getName().equals(Double.class.getName())) {
                types[i] = double.class;
            }
        }
    }

    private static Class getType(String name) {
        Class clazz = Classes.allClasses.get(name);

        return clazz;
    }

    private Method getMethod(Class clazz, String expectedName, Class<?>... parameterTypes) {
        Method method = null;

        try {
            method = clazz.getMethod(expectedName, parameterTypes);
        } catch (NoSuchMethodException e) {
        }

        return method;
    }
}

 */