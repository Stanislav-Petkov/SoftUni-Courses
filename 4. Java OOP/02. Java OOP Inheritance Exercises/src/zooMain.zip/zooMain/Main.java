package zooMain;

import zooMain.zoo.Animal;
import zooMain.zoo.Lizard;

public class Main {
    public static void main(String[] args) {
        Animal a = new Lizard("Gogg");
        System.out.print(a.getName());
    }
}
