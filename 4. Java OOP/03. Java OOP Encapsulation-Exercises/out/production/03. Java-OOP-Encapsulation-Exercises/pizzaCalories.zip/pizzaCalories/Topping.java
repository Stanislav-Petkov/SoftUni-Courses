package pizzaCalories;

import pizzaCalories.utils.TypeUtils;

public class Topping {
    private String toppingType;
    private double weight;

    public Topping(String toppingType,double weight){
        this.setToppingType(toppingType);
        this.setWeight(weight);
    }

    private void setToppingType(String toppingType) {
        if(!TypeUtils.TOPPING_TYPES.containsKey(toppingType)){

            String invalidType = String.format("Cannot place %s on top of your pizza.", toppingType);
            throw new IllegalArgumentException(invalidType);
        }
        this.toppingType = toppingType;
    }

    private void setWeight(double weight) {
        if (weight <1 || weight > 50){
            throw new IllegalArgumentException(this.toppingType + " weight should be in the range [1..50].");
        }
        this.weight = weight;
    }

    public double calculateCalories(){

    return this.weight * 2 * TypeUtils.TOPPING_TYPES.get(this.toppingType);
//        double toppingCalories = 2 * this.weight;
//        if(this.toppingType.equals("Meat")){
//            toppingCalories *= 1.2;
//        }else if(this.toppingType.equals("Veggies")){
//            toppingCalories *= 0.8;
//        }else if(this.toppingType.equals("Cheese")){
//            toppingCalories *= 1.1;
//        }else if(this.toppingType.equals("Sauce")){
//            toppingCalories *= 0.9;
//        }
//        return toppingCalories;//vrushta na 1 topping coloriite
    }
    //0.8 * 50 = 40
    //1.1 * 50 = 55
    //95 * 2
}

/*
package pizzaCalories;

public class Topping {
    private String toppingType;
    private double weight;

    public Topping(String toppingType,double weight){
        this.setToppingType(toppingType);
        this.setWeight(weight);
    }

    private void setWeight(double weight) {
        if (weight <1 || weight > 50){
            throw new IllegalArgumentException(this.toppingType + " weight should be in the range [1..50].");
        }
        this.weight = weight;
    }

    private void setToppingType(String toppingType) {
        if(!toppingType.equals("Meat") && !toppingType.equals("Veggies")
        && !toppingType.equals("Cheese") && !toppingType.equals("Sauce")){

            String invalidType = String.format("Cannot place %s on top of your pizza.", toppingType);
            throw new IllegalArgumentException(invalidType);
        }
        this.toppingType = toppingType;
    }

    public double calculateCalories(){

        double toppingCalories = 2 * this.weight;
        if(this.toppingType.equals("Meat")){
            toppingCalories *= 1.2;
        }else if(this.toppingType.equals("Veggies")){
            toppingCalories *= 0.8;
        }else if(this.toppingType.equals("Cheese")){
            toppingCalories *= 1.1;
        }else if(this.toppingType.equals("Sauce")){
            toppingCalories *= 0.9;
        }
        return toppingCalories;//vrushta na 1 topping coloriite
    }
    //0.8 * 50 = 40
    //1.1 * 50 = 55
    //95 * 2
}

 */
