package pizzaCalories;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

    }
}

/*

package pizzaCalories;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        String line1 = scanner.nextLine();
        String[] line1Pizza = line1.split("\\s+");
        String pizzaName = line1Pizza[1];
        int numberOfToppings = Integer.parseInt(line1Pizza[2]);
        try {
            Pizza pizza = new Pizza(pizzaName, numberOfToppings);


            String line2 = scanner.nextLine();
            String[] line2Dough = line2.split("\\s+");
            String flourType = line2Dough[1];
            String bakingTechnique = line2Dough[2];
            double weightInGrams = Double.parseDouble(line2Dough[3]);
            Dough dough = new Dough(flourType, bakingTechnique, weightInGrams);

            pizza.setDough(dough);

            String toppingInput = scanner.nextLine();
            while (!toppingInput.equals("END")) {
                String[] tokens = toppingInput.split("\\s+");
                String toppingType = tokens[1];
                double toppingWeightInGrams = Double.parseDouble(tokens[2]);
                Topping topping = new Topping(toppingType, toppingWeightInGrams);

                pizza.addToppings(topping);

                toppingInput = scanner.nextLine();
            }
            System.out.println(pizza);
        }catch (IllegalArgumentException e){
            System.out.println(e.getMessage());
        }

    }
}

package pizzaCalories;

import java.util.ArrayList;
import java.util.List;

public class Pizza {
    private String name;
    private Dough dough;
    private List<Topping> toppings;

    public Pizza(String name, int numberOfToppings){
        this.setName(name);
        this.setToppings(numberOfToppings);
        this.toppings = new ArrayList<>();
    }

    private void setToppings(int numberOfToppings) {
        if(numberOfToppings < 1 || numberOfToppings > 10){
            throw new IllegalArgumentException("Number of toppings should be in range [0..10].");
        }
    }

    private void setName(String name) {
        if( name == null || name.trim().isEmpty() || name.length() < 1 || name.length() > 15){
            throw new IllegalArgumentException("Pizza name should be between 1 and 15 symbols.");
        }
        this.name = name;
    }

    public void setDough(Dough dough) {
        this.dough = dough;
    }

    public String getName() {
        return this.name;
    }

    public void addToppings(Topping topping) {
        this.toppings.add(topping);
    }
    public double getOverallCalories(){
        return this.dough.calculateCalories() + + sumEachToppingCalories(this.toppings);

    }

    private double sumEachToppingCalories(List<Topping> toppings) {
        double sum = 0;
        for (int i = 0; i < toppings.size(); i++) {
            sum += toppings.get(i).calculateCalories();
        }
        return sum;
    }

    @Override
    public String toString(){
        return String.format(this.name + " - " + getOverallCalories());
    }
}

package pizzaCalories;

public class Dough {
    private String flourType;
    private String bakingTechnique;
    private double weight;

    public Dough(String flourType,String bakingTechnique,double weight){
        this.setFlourType(flourType);
        this.setBakingTechnique(bakingTechnique);
        this.setWeight(weight);
    }

    private void setFlourType(String flourType) {
        if(!flourType.equals("White") && !flourType.equals("Wholegrain")){
            throw new IllegalArgumentException("Invalid type of dough.");
        }
        this.flourType = flourType;

    }

    private void setBakingTechnique(String bakingTechnique) {
        if(!bakingTechnique.equals("Crispy") && !bakingTechnique.equals("Chewy")
        && !bakingTechnique.equals("Homemade")){
            throw new IllegalArgumentException("Invalid type of dough.");
        }
        this.bakingTechnique = bakingTechnique;

    }

    private void setWeight(double weight) {
        if(weight < 1 || weight > 200){
            throw new IllegalArgumentException("Dough weight should be in the range [1..200].");
        }
        this.weight = weight;
    }

    public double calculateCalories(){
        double doughCalories = 2 * this.weight;
        if (this.flourType.equals("White")){
            doughCalories *= 1.5;
        }else if(this.flourType.equals("Wholegrain")) {
            doughCalories *= 1.0;
        }

        if(this.bakingTechnique.equals("Crispy")){
            doughCalories *= 0.9;
        }else if(this.bakingTechnique.equals("Chewy")){
            doughCalories *= 1.1;
        }else if(this.bakingTechnique.equals("Homemade")){
            doughCalories *= 1.0;
        }
        return doughCalories ;//* 2 * weight;
    }
    //(2 * 100) * 1.0 * 0.9 = 180
}


package pizzaCalories;

public class Topping {
    private String toppingType;
    private double weight;

    public Topping(String toppingType,double weight){
        this.setToppingType(toppingType);
        this.setWeight(weight);
    }

    private void setWeight(double weight) {
        if (weight <1 || weight > 50){
            throw new IllegalArgumentException(this.toppingType + " weight should be in the range [1..50].");
        }
        this.weight = weight;
    }

    private void setToppingType(String toppingType) {
        if(!toppingType.equals("Meat") && !toppingType.equals("Veggies")
        && !toppingType.equals("Cheese") && !toppingType.equals("Sauce")){

            String invalidType = String.format("Cannot place %s on top of your pizza.", toppingType);
            throw new IllegalArgumentException(invalidType);
        }
        this.toppingType = toppingType;
    }

    public double calculateCalories(){

        double toppingCalories = 2 * this.weight;
        if(this.toppingType.equals("Meat")){
            toppingCalories *= 1.2;
        }else if(this.toppingType.equals("Veggies")){
            toppingCalories *= 0.8;
        }else if(this.toppingType.equals("Cheese")){
            toppingCalories *= 1.1;
        }else if(this.toppingType.equals("Sauce")){
            toppingCalories *= 0.9;
        }
        return toppingCalories;//vrushta na 1 topping coloriite
    }
    //0.8 * 50 = 40
    //1.1 * 50 = 55
    //95 * 2
}

 */
