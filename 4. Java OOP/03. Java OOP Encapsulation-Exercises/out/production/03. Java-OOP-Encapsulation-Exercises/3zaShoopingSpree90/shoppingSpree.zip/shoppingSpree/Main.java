package shoppingSpree;

import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String namesInput = scanner.nextLine();
        String[] names = namesInput.split(";");

        List<Person> personList = new LinkedList<>();

        for (int i = 0; i < names.length; i++) {
            String[] nameAndMoney = names[i].split("=");
            String name = nameAndMoney[0];
            try {
                double money = Double.parseDouble(nameAndMoney[1]);
                Person person = new Person(name,money);
                personList.add(person);
            }catch (IllegalArgumentException ex){
                System.out.println(ex.getMessage());
            }
        }


        List<Product> productList = new LinkedList<>();

        String productsInput = scanner.nextLine();
        String[] products = productsInput.split(";");
        for (int i = 0; i < products.length; i++) {
            String[] nameAndCost = products[i].split("=");
            String name = nameAndCost[0];
            double cost = Double.parseDouble(nameAndCost[1]);
            Product product = new Product(name,cost);
            productList.add(product);
        }


        String line = scanner.nextLine();
        while (!line.equals("END")){
            String[] nameProduct = line.split("\\s+");
            String name = nameProduct[0];
            String product = nameProduct[1];
            for (int i = 0; i < personList.size(); i++) {
                for (int j = 0; j < productList.size() ; j++) {

                    String personName = personList.get(i).getName();
                    String productName = productList.get(j).getName();
                    if(personName.equals(name) && productName.equals(product)){
                        Person person = personList.get(i);
                        Product product1 = productList.get(j);
                        person.buyProduct(product1);
                    }
                }
            }

            line = scanner.nextLine();
        }
        for (int i = 0; i < personList.size(); i++) {
            System.out.println(personList.get(i));
        }
    }
}
