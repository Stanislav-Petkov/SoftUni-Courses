package footballTeamGenerator;

import java.util.ArrayList;
import java.util.List;

public class Team {
    private String name;
    private List<Player> players;

    public Team(String name){
        this.setName(name);
        this.players = new ArrayList<>();
    }

    private void setName(String name) {
        if(name == null || name.trim().isEmpty()){
            throw new IllegalArgumentException("A name should not be empty.");
        }
        this.name = name.trim();
    }

    public String getName(){
        return this.name;
    }

    public void addPlayer(Player player){
        //ako go nqma otbora

//        if(this.name == null || this.name == null){
//            throw new IllegalArgumentException("Team "+ this.name +"does not exist.");
//        }
        this.players.add(player);
    }
    public void removePlayer(String playerName){

        //removeIf maha vsichki koito otgovarqt na daden predikat
       // this.players.removeIf(p -> p.getName().equals(playerName));
        //vseki player koito se sudurja negovoo ime trqbva da e ravno na
        //playernam

        int index = -1;
        for (int i = 0; i < this.players.size() ; i++) {
            if(this.players.get(i).getName().equals(playerName)){
                index = i;
                break;
            }
        }

        if(index != -1 || playerName == null){
            this.players.remove(index);
        }else {
            throw new IllegalArgumentException("Player " + playerName +" is not in " + this.name +" team.");
        }
    }
    public double getRating(){
        return this.players.stream()
                .mapToDouble(Player::overallSkillLevel)
                .average()//ako nqma subrani danni average e 0
                .orElse(0);
    }
}
