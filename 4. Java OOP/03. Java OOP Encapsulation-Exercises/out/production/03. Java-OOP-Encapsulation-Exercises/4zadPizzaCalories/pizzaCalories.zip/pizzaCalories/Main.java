package pizzaCalories;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        String line1 = scanner.nextLine();
        String[] line1Pizza = line1.split("\\s+");
        String pizzaName = line1Pizza[1];
        int numberOfToppings = Integer.parseInt(line1Pizza[2]);
        try {
            Pizza pizza = new Pizza(pizzaName, numberOfToppings);


            String line2 = scanner.nextLine();
            String[] line2Dough = line2.split("\\s+");
            String flourType = line2Dough[1];
            String bakingTechnique = line2Dough[2];
            double weightInGrams = Double.parseDouble(line2Dough[3]);
            Dough dough = new Dough(flourType, bakingTechnique, weightInGrams);

            pizza.setDough(dough);

            String toppingInput = scanner.nextLine();
            while (!toppingInput.equals("END")) {
                String[] tokens = toppingInput.split("\\s+");
                String toppingType = tokens[1];
                double toppingWeightInGrams = Double.parseDouble(tokens[2]);
                Topping topping = new Topping(toppingType, toppingWeightInGrams);

                pizza.addToppings(topping);

                toppingInput = scanner.nextLine();
            }
            System.out.println(pizza);
        }catch (IllegalArgumentException e){
            System.out.println(e.getMessage());
        }

    }
}
