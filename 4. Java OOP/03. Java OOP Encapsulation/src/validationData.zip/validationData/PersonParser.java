package validationData;

public class PersonParser {

    public static Person from(String line){
        String[] tokens = line.split("\\s+");
        String firstName = tokens[0];
        String lastName = tokens[1];
        int age = Integer.valueOf(tokens[2]);
        double salary = Double.valueOf(tokens[3]);

        return new Person(firstName,lastName,age,salary);

    }

    public static void main(String[] args) {
        try {
            Person p = PersonParser.from("A assen 6 6666");
            System.out.println(p);
        }catch (IllegalArgumentException iae){
            System.out.println(iae.getMessage());
        }



    }
}
