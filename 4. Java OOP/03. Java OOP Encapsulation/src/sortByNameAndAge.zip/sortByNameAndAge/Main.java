package sortByNameAndAge;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Main {
    public static void main(String[] args) throws IOException {

        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        int n = Integer.parseInt(reader.readLine());
        List<Person> people = new ArrayList<>();

        PersonParser personParser = new PersonParser();
        for (int i = 0; i < n; i++) {
            String input = reader.readLine();
            //people.add(new Person(input[0], input[1], Integer.parseInt(input[2])));
            people.add(PersonParser.personFrom (input));
        }

        Collections.sort(people,new PersonComparator());

        for (Person person : people) {
            System.out.println(person.toString());
        }
    }

}


/*
package sortByNameAndAge;

import java.util.*;

public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        int n = Integer.parseInt(scanner.nextLine());
        String[] tokens = scanner.nextLine().split("\\s+");
        List<Person> list = new ArrayList<>();
        while (n-- > 0){
            String firstName = tokens[0];
            String lastName = tokens[1];
            int age = Integer.parseInt(tokens[2]);
            Person person  = new Person(firstName,lastName,age);
            list.add(person);
            tokens = scanner.nextLine().split("\\s+");
        }
        Collections.sort(list, (firstPerson,secondPerson) -> {
            int result = firstPerson.getFirstName().compareTo(secondPerson.getFirstName());
            if(result != 0){
                return result;
            }else {
                return Integer.compare(firstPerson.getAge(),secondPerson.getAge());
            }
        });
        for (int i = 0; i < list.size(); i++) {
            System.out.println(list.get(i).toString());
        }
    }

package sortByNameAndAge;

import java.util.ArrayList;

public class Person implements Comparable<Person> {
    private String firstName;
    private String lastName;
    private int age;

    public Person(String firstName, String lastName, int age){
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
    }
    public String getFirstName() {
        return this.firstName;
    }

    public String getLastName() {
        return this.lastName;
    }

    public int getAge() {
        return this.age;
    }

    @Override
    public String toString(){
        return String.format("%s %s is %d years old.",
                this.getFirstName(), this.getLastName(),this.getAge());
    }

    @Override
    public int compareTo(Person o) {
        if(o.getFirstName().charAt(0) < this.getFirstName().charAt(0)) {
            return 0;
        }
        return 1;
    }

}



 */



















