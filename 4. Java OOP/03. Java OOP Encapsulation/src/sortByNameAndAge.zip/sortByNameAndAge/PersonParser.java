package sortByNameAndAge;

public class PersonParser {
    //poluchava 1 red i znae kak da napravi person
    //Asen Ivanov 65

    public static Person personFrom(String line){
        String[] split = line.split("\\s+");
        String firstName = split[0];
        String lastName = split[1];
        int age = Integer.valueOf(split[2]);
        return  new Person(firstName,lastName,age);

    }

//    public static void main(String[] args) {
//        PersonParser personParser = new PersonParser();
//        Person person = personParser.personFrom("Asen Ivanov 65");
//
//        System.out.println(person);
//    }

}
