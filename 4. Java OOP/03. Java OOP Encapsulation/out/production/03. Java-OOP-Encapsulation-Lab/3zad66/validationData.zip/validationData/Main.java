package validationData;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        int n = Integer.parseInt(reader.readLine());

        List<Person> list = new ArrayList<>();
        PersonParser personParser = new PersonParser();
        for (int i = 0; i < n; i++) {
            Person person = personParser.parseFrom(reader.readLine());
            if(person.getFirstName() == null || person.getLastName() == null ||
            person.getAge() <= 0 || person.getSalary() < 460){
                continue;
            }
            list.add(person);
        }
        int bonus = Integer.parseInt(reader.readLine());
        for(Person person : list){
            person.increaseSalary(bonus);
            System.out.println(person);
        }
    }
}
/*
package salaryIncrease;

import java.text.DecimalFormat;

public class Person {
    private String firstName;
    private String lastName;
    private int age;
    private double salary;
    public Person(String firstName,String lastName,int age,double salary){
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
        this.salary = salary;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public int getAge() {
        return age;
    }

    public double getSalary() {
        return salary;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    @Override
    public String toString(){
        DecimalFormat df = new DecimalFormat("######.0######");
        return String.format("%s %s gets %s leva",
                this.firstName,this.lastName,df.format(this.salary));
    }
    public void increaseSalary(double bonus){
        double bonusInLeva;
        if (this.age < 30){
            bonusInLeva = this.salary * (bonus / 200);
            this.salary = this.salary +  bonusInLeva;
        }else {
            bonusInLeva = this.salary * (bonus / 100);
            this.salary = this.salary + bonusInLeva;
        }
    }
}

package salaryIncrease;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        int n = Integer.parseInt(reader.readLine());

        List<Person> list = new ArrayList<>();
        PersonParser personParser = new PersonParser();
        for (int i = 0; i < n; i++) {
            Person person = personParser.parseFrom(reader.readLine());
            list.add(person);
        }
        int bonus = Integer.parseInt(reader.readLine());
        for(Person person : list){
            person.increaseSalary(bonus);
            System.out.println(person);
        }
    }
}
package salaryIncrease;

public class PersonParser {

    public Person parseFrom(String line){
        String[] tokens = line.split("\\s+");
        String firstName = tokens[0];
        String lastName = tokens[1];
        int age = Integer.valueOf(tokens[2]);
        double salary = Double.valueOf(tokens[3]);
        return new Person(firstName,lastName,age,salary);
    }
}

 */