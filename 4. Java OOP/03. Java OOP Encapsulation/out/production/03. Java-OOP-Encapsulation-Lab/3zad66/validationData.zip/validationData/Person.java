package validationData;

public class Person {
     String firstName;
     String lastName;
     int age;
     double salary;

    public Person(String firstName, String lastName, int age, double salary) {
        this.setFirstName(firstName);
        this.setLastName(lastName);
        this.setAge(age);
        this.setSalary(salary);
    }

    private void setLastName(String lastName) {
        try {
            if (lastName.length() < 3) {
                throw new IllegalArgumentException("Last name cannot be less than 3 symbols");
            }else {
                this.lastName = lastName;
            }
        }catch (IllegalArgumentException ex){
            System.out.println("Last name cannot be less than 3 symbols");
            return;
        }
    }

    public String getLastName() {
        return this.lastName;
    }

    private void setAge(int age) {
        try {
            if (age <= 0) {
                throw new IllegalArgumentException("Age cannot be zero or negative integer");
            }else {
                this.age = age;
            }
        }catch (IllegalArgumentException ex){
            System.out.println("Age cannot be zero or negative integer");
            return;
        }
    }

    public int getAge() {
        return this.age;
    }

    private void setFirstName(String firstName) {
        try {
            if (firstName.length() < 3) {
                throw new IllegalArgumentException("First name cannot be less than 3 symbols");
            }else {
                this.firstName = firstName;
            }
        }catch (IllegalArgumentException il){
            System.out.println("First name cannot be less than 3 symbols");
        }
    }

    public String getFirstName() {
        return this.firstName;
    }

    public void setSalary(double salary) {
        try {
            if (salary < 460) {
                throw new IllegalArgumentException("Salary cannot be less than 460 leva");
            }
            this.salary = salary;
        }catch (IllegalArgumentException il){
            System.out.println("Salary cannot be less than 460 leva");
        }
    }

    public double getSalary() {
        return this.salary;
    }

    @Override
    public String toString() {

        return String.format("%s %s gets %s leva",
                this.getFirstName(), this.getLastName(), this.getSalary());
    }

    public void increaseSalary(double bonusPercentage) {
        double baseBonus = this.getSalary() * bonusPercentage / 100;
        if (this.getAge() < 30) {
            this.setSalary(this.getSalary() + baseBonus / 2);
        } else {
            this.setSalary(this.getSalary() + baseBonus);
        }

    }
}









