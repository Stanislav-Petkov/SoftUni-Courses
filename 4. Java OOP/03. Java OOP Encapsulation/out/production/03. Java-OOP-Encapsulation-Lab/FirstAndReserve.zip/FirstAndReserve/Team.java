package FirstAndReserve;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

public class Team {
    private String name;
    private List<Person> firstTeam;
    private List<Person> reserveTeam;

    Team(String name){
        this.name = name;
        this.firstTeam = new ArrayList<>();
        this.reserveTeam = new ArrayList<>();
    }
    public String getName(){
        return name;
    }
    private void setName(String name){
        this.name = name;
    }
    public void addPlayer(Person person){
        if(person.getAge() < 40){
            firstTeam.add(person);
        }else {
            reserveTeam.add(person);
        }
    }
    public List<Person> getFirstTeam(){
        return  this.firstTeam;
    }
    public List<Person> getReserveTeam(){
        return this.reserveTeam;
    }

    public static void main(String[] args) {
        Team team = new Team("Black Eagles");

//        for(Person player : players){
//            team.addPlayer(player);
//        }
        System.out.println("First team have " +
                team.getFirstTeam().size() + " players");
        System.out.println("Reserve team have " +
                team.getReserveTeam().size() + " players");
    }
}
