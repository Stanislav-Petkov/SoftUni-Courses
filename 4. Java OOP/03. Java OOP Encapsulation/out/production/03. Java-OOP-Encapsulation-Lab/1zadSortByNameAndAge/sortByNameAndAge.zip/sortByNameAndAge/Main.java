package sortByNameAndAge;

import java.util.*;

public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        int n = Integer.parseInt(scanner.nextLine());
        String[] tokens = scanner.nextLine().split("\\s+");
        List<Person> list = new ArrayList<>();
        while (n-- > 0){
            String firstName = tokens[0];
            String lastName = tokens[1];
            int age = Integer.parseInt(tokens[2]);
            Person person  = new Person(firstName,lastName,age);
            list.add(person);
            tokens = scanner.nextLine().split("\\s+");
        }
        Collections.sort(list, (firstPerson,secondPerson) -> {
            int result = firstPerson.getFirstName().compareTo(secondPerson.getFirstName());
            if(result != 0){
                return result;
            }else {
                return Integer.compare(firstPerson.getAge(),secondPerson.getAge());
            }
        });
        for (int i = 0; i < list.size(); i++) {
            System.out.println(list.get(i).toString());
        }
    }
}





















