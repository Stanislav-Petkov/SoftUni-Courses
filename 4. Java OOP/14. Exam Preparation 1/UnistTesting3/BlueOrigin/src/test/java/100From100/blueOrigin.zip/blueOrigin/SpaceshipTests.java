package blueOrigin;

import org.junit.Assert;
import org.junit.Test;


public class SpaceshipTests {
    //TODO: TEST ALL THE FUNCTIONALITY OF THE PROVIDED CLASS Spaceship
    private static final String INVALID_SPACESHIP_NAME = "Invalid spaceship name!";
    private static final String INVALID_CAPACITY = "Invalid capacity!";
    private static final String SPACESHIP_FULL = "Spaceship is full!";
    private static final String ASTRONAUT_EXIST = "Astronaut %s is already in!";
    private static final int ZERO_CAPACITY = 0;

    @Test
    public void TestCreationAndCapacity() {
        Spaceship spaceship = new Spaceship("NAME", 5);
        Assert.assertEquals(5, spaceship.getCapacity());
    }

    @Test(expected = IllegalArgumentException.class)
    public void TestCreationIllegalCapacity() {
        Spaceship spaceship = new Spaceship("NAME", -5);
    }

    @Test
    public void testGetCount() {
        Spaceship spaceship = new Spaceship("NAME", 5);
        Assert.assertEquals(0, spaceship.getCount());
    }

    @Test
    public void testGetName() {
        Spaceship spaceship = new Spaceship("NAME", 5);
        Assert.assertEquals("NAME", spaceship.getName());
    }

    @Test(expected = NullPointerException.class)
    public void testSetIllegalName() {
        Spaceship spaceship = new Spaceship("", 1);
    }

    @Test(expected = NullPointerException.class)
    public void testSetIllegalNullName() {
        Spaceship spaceship = new Spaceship(null, 1);
    }


    @Test
    public void testRemoveNotValidName() {
        Spaceship spaceship = new Spaceship("NAME", 5);
        spaceship.add(new Astronaut("NAME1", 11.0));
        spaceship.add(new Astronaut("NAME2", 11.0));
        spaceship.add(new Astronaut("NAME3", 11.0));

        Assert.assertFalse(spaceship.remove("NAME33"));
    }

    @Test
    public void testRemoveNotValidName1() {
        Spaceship spaceship = new Spaceship("NAME", 5);
        spaceship.add(new Astronaut("NAME1", 11.0));
        spaceship.add(new Astronaut("NAME2", 11.0));
        spaceship.add(new Astronaut("NAME3", 11.0));

        Assert.assertTrue(spaceship.remove("NAME3"));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAddMoreThanCapacityException() {
        Spaceship spaceship = new Spaceship("NAME", 5);
        spaceship.add(new Astronaut("NAME1", 11.0));
        spaceship.add(new Astronaut("NAME2", 11.0));
        spaceship.add(new Astronaut("NAME3", 11.0));
        spaceship.add(new Astronaut("NAME4", 11.0));
        spaceship.add(new Astronaut("NAME5", 11.0));
        spaceship.add(new Astronaut("NAME6", 11.0));
    }

    @Test
    public void testAddNoException() {
        Spaceship spaceship = new Spaceship("NAME", 5);
        spaceship.add(new Astronaut("NAME1", 11.0));
        spaceship.add(new Astronaut("NAME2", 11.0));
        spaceship.add(new Astronaut("NAME3", 11.0));
        spaceship.add(new Astronaut("NAME4", 11.0));
        Assert.assertEquals(4, spaceship.getCount());
    }

    @Test
    public void testAddTrue() {
        Spaceship spaceship = new Spaceship("NAME", 5);
        spaceship.add(new Astronaut("NAME1", 11.0));
        spaceship.add(new Astronaut("NAME2", 11.0));
        spaceship.add(new Astronaut("NAME3", 11.0));
        spaceship.add(new Astronaut("NAME4", 11.0));

    }

    @Test(expected = IllegalArgumentException.class)
    public void testAddExistingAstronaut1() {
        Spaceship spaceship = new Spaceship("NAME", 5);
        spaceship.add(new Astronaut("NAME1", 11.0));
        spaceship.add(new Astronaut("NAME2", 11.0));
        spaceship.add(new Astronaut("NAME3", 11.0));
        spaceship.add(new Astronaut("NAME3", 11.0));
    }


    @Test
    public void testRemove() {
        Spaceship spaceship = new Spaceship("NAME", 5);
        spaceship.add(new Astronaut("NAME1", 11.0));
        spaceship.add(new Astronaut("NAME2", 11.0));
        spaceship.add(new Astronaut("NAME3", 11.0));
        spaceship.remove("NAME3");
        Assert.assertEquals(2, spaceship.getCount());
    }

    @Test
    public void testRemoveFalse() {
        Spaceship spaceship = new Spaceship("NAME", 5);
        spaceship.add(new Astronaut("NAME1", 11.0));
        spaceship.add(new Astronaut("NAME2", 11.0));
        spaceship.add(new Astronaut("NAME3", 11.0));
        Assert.assertFalse(spaceship.remove("NAME33"));
    }

    @Test
    public void testRemoveTrue() {
        Spaceship spaceship = new Spaceship("NAME", 5);
        spaceship.add(new Astronaut("NAME1", 11.0));
        spaceship.add(new Astronaut("NAME2", 11.0));
        spaceship.add(new Astronaut("NAME3", 11.0));
        Assert.assertTrue(spaceship.remove("NAME3"));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testSetCapacityException() {
        Spaceship spaceship = new Spaceship("NAME", -1);
    }


}
