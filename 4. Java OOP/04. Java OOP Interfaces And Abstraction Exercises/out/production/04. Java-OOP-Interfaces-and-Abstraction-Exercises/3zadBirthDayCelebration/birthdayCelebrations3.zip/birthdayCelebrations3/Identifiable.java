package birthdayCelebrations3;

public interface Identifiable {
    public String getId();

}
