package birthdayCelebrations3;


import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String line = scanner.nextLine();

        List<Citizen> citizens = new ArrayList<>();
        List<Pet> pets = new ArrayList<>();

        while (!line.equals("End")) {
            String[] tokens = line.split("\\s+");
            String command = tokens[0];
            switch (command) {
                case "Citizen": {
                    String name = tokens[1];
                    int age = Integer.parseInt(tokens[2]);
                    String id = tokens[3];
                    String birthDate = tokens[4];
                    Citizen citizen = new Citizen(name, age, id, birthDate);
                    citizens.add(citizen);
                    break;
                }
                case "Pet": {
                    String name = tokens[1];
                    String birthDate = tokens[2];
                    Pet pet = new Pet(name,birthDate);
                    pets.add(pet);
                    break;
                }
                case "Robot":{
                    String id = tokens[1];
                    String model =tokens[2];
                    Robot robot = new Robot(id,model);
                    break;
                }
            }
            line = scanner.nextLine();
        }
        int inputYear = Integer.parseInt(scanner.nextLine());
        for (int i = 0; i < citizens.size(); i++) {
            String birthDate = citizens.get(i).getBirthDate();
            String[] tokens = birthDate.split("/");
            int year = Integer.parseInt(tokens[2]);
            if(year == inputYear){
                System.out.println(birthDate);
            }
        }
        for (int i = 0; i < pets.size(); i++) {
            String birthDate = pets.get(i).getBirthDate();
            String[] tokens = birthDate.split("/");
            int year = Integer.parseInt(tokens[2]);
            if(year == inputYear){
                System.out.println(birthDate);
            }
        }
    }
}

/*
package defineInterfacePerson1;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Class[] citizenInterfaces = Citizen.class.getInterfaces();
        if(Arrays.asList(citizenInterfaces).contains(Person.class)){
            Method[] fields = Person.class.getDeclaredMethods();
            Scanner scanner = new Scanner(System.in);

            String name = scanner.nextLine();
            int age = Integer.parseInt(scanner.nextLine());
            Person person = new Citizen(name,age);

            System.out.println(fields.length);
            System.out.println(person.getName());
            System.out.println(person.getAge());
        }
    }
}

 */