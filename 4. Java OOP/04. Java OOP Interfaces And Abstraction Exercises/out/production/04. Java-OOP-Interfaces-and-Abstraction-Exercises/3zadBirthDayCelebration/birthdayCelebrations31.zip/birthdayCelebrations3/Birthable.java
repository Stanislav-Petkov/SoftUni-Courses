package birthdayCelebrations3;

public interface Birthable {
    public String getBirthDate();
}
