package birthdayCelebrations3;


import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String line = scanner.nextLine();

        List<Birthable> birthables = new ArrayList<>();
       // List<Citizen> citizens = new ArrayList<>();
       // List<Pet> pets = new ArrayList<>();


        while (!line.equals("End")) {
            String[] tokens = line.split("\\s+");
            String command = tokens[0];
            switch (command) {
                case "Citizen": {
                    String name = tokens[1];
                    int age = Integer.parseInt(tokens[2]);
                    String id = tokens[3];
                    String birthDate = tokens[4];
                    Citizen citizen = new Citizen(name, age, id, birthDate);
                    birthables.add(citizen);
                    break;
                }
                case "Pet": {
                    String name = tokens[1];
                    String birthDate = tokens[2];
                    Pet pet = new Pet(name,birthDate);
                    birthables.add(pet);
                    break;
                }
                case "Robot":{
                    String id = tokens[1];
                    String model =tokens[2];
                    Robot robot = new Robot(id,model);
                    break;
                }
            }
            line = scanner.nextLine();
        }
        String year = scanner.nextLine();

        for(Birthable birthable : birthables){
            if(birthable.getBirthDate().endsWith(year)){
                System.out.println(birthable.getBirthDate());
            }
        }
    }
}

/*

package birthdayCelebrations3;


import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String line = scanner.nextLine();

        List<Birthable> birthables = new ArrayList<>();


        while (!line.equals("End")) {
            String[] tokens = line.split("\\s+");
            String command = tokens[0];
            switch (command) {
                case "Citizen": {
                    String name = tokens[1];
                    int age = Integer.parseInt(tokens[2]);
                    String id = tokens[3];
                    String birthDate = tokens[4];
                    Citizen citizen = new Citizen(name, age, id, birthDate);
                    birthables.add(citizen);
                    break;
                }
                case "Pet": {
                    String name = tokens[1];
                    String birthDate = tokens[2];
                    Pet pet = new Pet(name,birthDate);
                    birthables.add(pet);
                    break;
                }
                case "Robot":{
                    String id = tokens[1];
                    String model =tokens[2];
                    Robot robot = new Robot(id,model);
                    break;
                }
            }
            line = scanner.nextLine();
        }
        int inputYear = Integer.parseInt(scanner.nextLine());
        for (int i = 0; i < birthables.size(); i++) {
            String birthDate = birthables.get(i).getBirthDate();
            String[] tokens = birthDate.split("/");
            int year = Integer.parseInt(tokens[2]);
            if(year == inputYear){
                System.out.println(birthDate);
            }
        }

    }
}

 */