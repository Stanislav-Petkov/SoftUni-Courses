package multipleImplementation;

public interface Identifiable {
    public String getId();

}
