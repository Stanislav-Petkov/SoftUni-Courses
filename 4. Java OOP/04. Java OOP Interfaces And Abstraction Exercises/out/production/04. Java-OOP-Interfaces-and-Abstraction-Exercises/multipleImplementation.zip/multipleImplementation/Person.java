package multipleImplementation;

public interface Person {
     String getName();
    int getAge();
}

/*
package defineInterfacePerson1;

public interface Person {
    public String getName();
    public int getAge();
}

 */