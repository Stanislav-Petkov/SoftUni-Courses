package telephony;

public interface Browsable {
    public String browse();
}
