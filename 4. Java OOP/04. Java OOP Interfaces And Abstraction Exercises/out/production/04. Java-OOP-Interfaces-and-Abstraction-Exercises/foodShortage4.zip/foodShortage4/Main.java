package foodShortage4;


import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        int n = Integer.parseInt(scanner.nextLine());
        List<Citizen> citizens = new ArrayList<>();
        List<Rebel> rebels = new ArrayList<>();

        while (n-- > 0) {
            String line = scanner.nextLine();
            String[] tokens = line.split("\\s+");
            if (tokens.length == 4) {
                Citizen citizen = new Citizen(tokens[0], Integer.parseInt(tokens[1]),tokens[2], tokens[3]);
                citizen.buyFood();
                citizens.add(citizen);

            } else if (tokens.length == 3) {
                Rebel rebel = new Rebel(tokens[0], Integer.parseInt(tokens[1]),
                        tokens[2]);
                rebel.buyFood();

                rebels.add(rebel);
            }
            //line = scanner.nextLine();
        }

        //people who bought food
        String input = scanner.nextLine();
        int sum = 0;
        while (!input.equals("End")) {
            for (int i = 0; i < citizens.size(); i++) {
                if(citizens.get(i).getName().equals(input)){
                    sum += citizens.get(i).getFood();
                }
            }
            for (int i = 0; i < rebels.size(); i++) {
                if(rebels.get(i).getName().equals(input)){
                    sum += rebels.get(i).getFood();
                }
            }
            input = scanner.nextLine();
        }
        System.out.println(sum);

    }
}

/*
package defineInterfacePerson1;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Class[] citizenInterfaces = Citizen.class.getInterfaces();
        if(Arrays.asList(citizenInterfaces).contains(Person.class)){
            Method[] fields = Person.class.getDeclaredMethods();
            Scanner scanner = new Scanner(System.in);

            String name = scanner.nextLine();
            int age = Integer.parseInt(scanner.nextLine());
            Person person = new Citizen(name,age);

            System.out.println(fields.length);
            System.out.println(person.getName());
            System.out.println(person.getAge());
        }
    }
}

 */