package foodShortage4;

public interface Identifiable {
    public String getId();

}
