package foodShortage4;

public interface Buyer {
    public void buyFood();
    public int getFood();
}
