package foodShortage4;

public interface Birthable {
    public String getBirthDate();
}
