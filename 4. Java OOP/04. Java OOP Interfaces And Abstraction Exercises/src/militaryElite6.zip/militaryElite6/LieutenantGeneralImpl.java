package militaryElite6;

import militaryElite6.interfaces.LieutenantGeneral;

import java.util.HashSet;
import java.util.Set;

public class LieutenantGeneralImpl extends PrivateImpl implements LieutenantGeneral {
    Set<PrivateImpl> privates;


    public LieutenantGeneralImpl(int id,String firstName, String lastName,  double salary) {
        super(id,firstName, lastName,  salary);
        this.privates = new HashSet<>();
    }

    public void addPrivate(PrivateImpl priv){
        this.privates.add(priv);
    }

    @Override
    public Set<PrivateImpl> getPrivate() {
        return this.privates;
    }
}
