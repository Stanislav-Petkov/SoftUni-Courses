package militaryElite6;

import militaryElite6.enumerations.Corps;
import militaryElite6.enumerations.EnumMission;

import java.util.*;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        String line = scanner.nextLine();
        Set<PrivateImpl> privates = new HashSet<>();
        while (!line.equals("End")) {
            //"Private <id> <firstName> <lastName> <salary>"
            String[] tokens = line.split("\\s+");
            String command = tokens[0];
            switch (command) {
                case "Private":
                    PrivateImpl pr = new PrivateImpl(Integer.parseInt(tokens[1]), tokens[2],
                            tokens[3], Double.parseDouble(tokens[4]));
                    System.out.println(pr.toString());
                    privates.add(pr);
                    break;
                case "LeutenantGeneral": {
                    int id = Integer.parseInt(tokens[1]);
                    String firstName = tokens[2];
                    String lastName = tokens[3];
                    double salary = Double.parseDouble(tokens[4]);

                    LieutenantGeneralImpl liuetenant = new LieutenantGeneralImpl(id, firstName, lastName, salary);
                    System.out.println(liuetenant);
                    System.out.println("Privates:");
                    if (privates.size() != 0) {
                        for (PrivateImpl p : privates) {
                            liuetenant.addPrivate(p);
                        }
                    }

                    Set<PrivateImpl> privates1 = liuetenant.getPrivate();
                    Set<PrivateImpl> privatesResult = new HashSet<>();

                    privatesResult = privates1.stream()
                            .sorted((a, b) -> b.id - a.id)
                            .collect(Collectors.toCollection(LinkedHashSet::new));

                    if (privatesResult.size() != 0) {

                        for (PrivateImpl p : privatesResult) {
                            System.out.println("  " + p.toString());
                        }
                    }
                    break;
                }
                case "Engineer": {
                    int id = Integer.parseInt(tokens[1]);
                    String firstName = tokens[2];
                    String lastName = tokens[3];
                    double salary = Double.parseDouble(tokens[4]);
                    String corpsValue = tokens[5];
                    Corps corps = null;
                    boolean corpsValid = true;
                    if (corpsValue.equals("Airforces")) {
                        corps = Corps.Airforces;
                    } else if (corpsValue.equals("Marines")) {
                        corps = Corps.Marines;
                    } else {
                        corpsValid = false;
                    }

                    if(corpsValid) {
                        EngineerImpl engineer = new EngineerImpl(id, firstName, lastName, salary, corps);
                        for (int i = 6; i < tokens.length; i += 2) {
                            String partName = tokens[i];
                            int workedHours = Integer.parseInt(tokens[i + 1]);
                            Repair repair = new Repair(partName, workedHours);
                            engineer.addRepair(repair);
                        }

                        System.out.println(engineer.toString());
                        System.out.print("Corps: ");
                        System.out.println(engineer.corps);
                        System.out.println("Repairs: ");
                        if (engineer.repairSet.size() > 0) {
                            for (Repair repair : engineer.repairSet) {
                                System.out.print("  " + repair.toString());
                            }
                        }
                    }
                    break;
                }
                case "Commando": {
                    int id = Integer.parseInt(tokens[1]);
                    String firstName = tokens[2];
                    String lastName = tokens[3];
                    double salary = Double.parseDouble(tokens[4]);
                    String corpsValue = tokens[5];
                    //suzdava Missions
                    Corps corps = null;
                    boolean corpsValid = true;
                    if (corpsValue.equals("Airforces")) {
                        corps = Corps.Airforces;
                    } else if (corpsValue.equals("Marines")) {
                        corps = Corps.Marines;
                    } else {
                        corpsValid = false;
                    }
                    //ne se suzdava Commando ako e navaliden corpse
                    if (corpsValid) {
                        CommandoImpl commando = new CommandoImpl(id, firstName, lastName, salary, corps);
                        Mission mission = null;

                        if (tokens.length > 6) {
                            for (int i = 6; i < tokens.length; i += 2) {
                                String missionCodeName = tokens[i];
                                String missionState = tokens[i + 1];


                                if (missionState.equals("finished")) {
                                    mission = new Mission(missionCodeName, EnumMission.finished);
                                } else if (missionState.equals("inProgress")) {
                                    mission = new Mission(missionCodeName, EnumMission.inProgress);
                                }
                                if (mission != null) {
                                    commando.addMission(mission);
                                }
                            }

                        }


                        System.out.println(commando.toString());

                        System.out.print("Corps: ");  //print cops
                        System.out.println(commando.corps);

                        System.out.println("Missions:");  //print missions
                        Collection<Mission> allMissions = commando.getMissions();
                        if (allMissions.size() != 0) {
                            for (Mission mission1 : allMissions) {
                                System.out.printf("Code Name: " + mission1.codeName + " State: " + mission1.state.toString() + "%n");
                            }
                        } else {
                            break;
                        }
                    }
                    break;
                }
                case "Spy":
                    int id = Integer.parseInt(tokens[1]);
                    String firstName = tokens[2];
                    String lastName = tokens[3];
                    String codeNumber = tokens[4];
                    SpyImpl spy = new SpyImpl(id, firstName, lastName, codeNumber);
                    System.out.println(spy.toString());
                    break;
            }

            line = scanner.nextLine();

        }
    }
}
