package militaryElite6;

import militaryElite6.enumerations.Corps;
import militaryElite6.interfaces.Commando;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

public class CommandoImpl extends SoldierImpl implements Commando {
    Set<Mission> missionSet;
    double salary;
    Corps corps;

    CommandoImpl(int id, String firstName, String lastName, double salary, Corps corps){
        super(id,firstName,lastName);
        this.salary = salary;
        this.corps = corps;
        this.missionSet = new HashSet<>();
    }
    public void addMission(Mission mission){
        this.missionSet.add(mission);
        for(Mission m : this.missionSet){
            if(m.state.toString().equals("finished")){
                this.missionSet.remove(m);
            }
        }
    }
    public void completeMission(){
        for(Mission m : this.missionSet){
            if(m.state.toString().equals("finished")){
                this.missionSet.remove(m);
            }
        }
    }
    public Collection<Mission> getMissions(){
     //   this.completeMission();
        return this.missionSet;
    }

    @Override
    public String toString(){
        return String.format("Name: %s %s Id: %d Salary: %.2f",
                super.getFirstName(),
                super.getLastName(),
                super.getId(),
                this.salary);
    }
}
