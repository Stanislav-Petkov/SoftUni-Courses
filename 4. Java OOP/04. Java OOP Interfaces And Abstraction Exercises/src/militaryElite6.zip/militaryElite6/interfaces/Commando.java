package militaryElite6.interfaces;

import militaryElite6.Mission;

import java.util.Collection;

public interface Commando {

    public void addMission(Mission mission);
    public Collection<Mission> getMissions();
}
