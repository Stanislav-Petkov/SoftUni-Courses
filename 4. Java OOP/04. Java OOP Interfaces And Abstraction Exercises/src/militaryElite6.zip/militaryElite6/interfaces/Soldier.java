package militaryElite6.interfaces;

public interface Soldier {
    public int getId();
    public String getFirstName();
    public String getLastName();
}
