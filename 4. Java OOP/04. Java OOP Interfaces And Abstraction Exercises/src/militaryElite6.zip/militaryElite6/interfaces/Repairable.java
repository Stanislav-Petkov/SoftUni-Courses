package militaryElite6.interfaces;

public interface Repairable {
    public String getPartName() ;
    public void setPartName(String partName);
    public int getHoursWorked();
    public void setHoursWorked(int hoursWorked);
}
