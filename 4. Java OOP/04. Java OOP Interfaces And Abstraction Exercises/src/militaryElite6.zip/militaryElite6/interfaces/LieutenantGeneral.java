package militaryElite6.interfaces;

import militaryElite6.PrivateImpl;

import java.util.Set;

public interface LieutenantGeneral {
    public Set<PrivateImpl> getPrivate();
}
