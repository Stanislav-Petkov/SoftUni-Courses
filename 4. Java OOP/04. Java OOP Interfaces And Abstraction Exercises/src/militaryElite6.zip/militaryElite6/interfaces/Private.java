package militaryElite6.interfaces;

public interface Private {
    public double getSalary();
}
