package militaryElite6.enumerations;

public enum Corps {
    Airforces("Airforces"),
    Marines("Marines");

    public final String corp;

    Corps(String corp){
        this.corp = corp;
    }
}
