package militaryElite6;

import militaryElite6.enumerations.EnumMission;

public class Mission {
    String codeName;
    EnumMission state;

    public Mission(String codeName,EnumMission state){
        this.codeName = codeName;
        this.state = state;
    }
    @Override
    public String toString(){
        return codeName + " " + state;
    }
}
