package militaryElite6;

import militaryElite6.enumerations.Corps;
import militaryElite6.interfaces.Engineer;

import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class EngineerImpl extends SoldierImpl implements Engineer {
    Set<Repair> repairSet;
    double salary;
    Corps corps;

    public EngineerImpl(int id, String firstName, String lastName, double salary,Corps corps){
        super(id,firstName,lastName);
        this.salary = salary;
        this.corps = corps;
        this.repairSet = new HashSet<>();
    }
    public void addRepair(Repair repair){
        this.repairSet.add(repair);
    }

    public Collection<Repair> getRepairs(){
        return repairSet;
    }

    @Override
    public String toString(){
        return String.format("Name: %s %s Id: %d Salary: %.2f",
                super.getFirstName(),
                super.getLastName(),
                super.getId(),
                this.salary);
    }
}
