package hotelReservation;

public class InputDataReservationParser {

//50.25 5 Summer VIP
    //“<pricePerDay> <numberOfDays> <season> <discountType>”,
    public Reservation parseFromLine(String line){
        String[] split = line.split("\\s+");
        double pricePerDay = Double.valueOf(split[0]);
        int numberOfDays = Integer.valueOf(split[1]);
        Season season = Season.valueOf(split[2].toUpperCase());
        Discount discount = Discount.valueOf(split[3].toUpperCase());
        return new Reservation(pricePerDay,numberOfDays,
                season,discount);
    }


}
