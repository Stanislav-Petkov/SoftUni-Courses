//package hotelReservation;
//
//public class PriceCalculator {
//
//    private Reservation reservation;
//    PriceCalculator(Reservation reservation){
//        this.reservation = reservation;
//    }
//
//
//    public double calculate() {
//        System.out.println("just calculare a reservation: " + reservation.toString());
//        return this.reservation.calculatePrice();
//    }
//}
//
///*
//package hotelReservation;
//
//public class PriceCalculator {
//
//    PriceCalculator(Reservation reservation){
//
//    }
//
//    public static void main(String[] args) {
//        double price = 15.5;
//        Season season = Season.SPRING;
//
//        //using getter
//        double currentPrice = price * season.getPriceMultiplier();
//        //using method
//        double newPrice = season.multipliedPrice(price);
//
//        System.out.println(currentPrice);
//        System.out.println(newPrice);
//    }
//
//}
//
//package hotelReservation;
//
//public enum Season {
//    AUTUMN(1),
//    SPRING(2),
//    WINTER(3),
//    SUMMER(4);
//
//    private int priceMultiplier;
//
//    Season(int priceMultiplier){
//        this.priceMultiplier = priceMultiplier;
//    }
//
//    public double multipliedPrice(double price){
//        return price * this.priceMultiplier;
//    }
//
//    public int getPriceMultiplier(){
//        return this.priceMultiplier;
//    }
//}
// */
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
