package carShop;

public interface Car {
    public int TIRES = 4;
    public String getModel();
    public String getColor();
    public Integer getHorsePower();
    public String countryProduced();
}
