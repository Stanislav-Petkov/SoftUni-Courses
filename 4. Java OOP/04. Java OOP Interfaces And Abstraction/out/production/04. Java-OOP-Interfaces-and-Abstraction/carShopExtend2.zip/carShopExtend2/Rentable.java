package carShopExtend2;

public interface Rentable extends Car {
    public Integer getMinRentDay();
    public Double getPricePerDay();
}
