package carShopExtend2;

public interface Sellable {
     Double getPrice();
}
