package carShopExtend2;

public interface Rentable {
    public Integer getMinRentDay();
    public Double getPricePerDay();
}
