package carShopExtend2;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

public class Main {
    public static void main(String[] args) {
        Sellable seat = new Seat("Leon", "Gray", 110, "Spain",11111.1);
        Rentable audi = new Audi("A4","Gray",110,
                "Germany",3,99.9);

        printCarInfo((Car) seat);
        printCarInfo((Car) audi);
    }
    private static void printCarInfo(Car car){
        System.out.println(String.format(
                "%s is %s color and have %s horse power",
                car.getModel(),
                car.getColor(),
                car.getHorsePower()));
        System.out.println(car.toString());
    }
}

/*
package carShop;

public class Main {
    public static void main(String[] args) {
        Car seat = new Seat("Leon", "gray", 110, "Spain");
        System.out.println(String.format(
                "%s is %s color and have %s horse power",
                seat.getModel(),
                seat.getColor(),
                seat.getHorsePower()));
        System.out.println(seat.toString());
    }
}

package carShop;

import java.io.Serializable;

public class Seat implements Car,Serializable{
    private String model;
    private String color;
    private Integer horsePower;
    private String countryProduced;
    public Seat(String model,String color,Integer horsePower,String countryProduced){
        this.model = model;
        this.color = color;
        this.horsePower = horsePower;
        this.countryProduced = countryProduced;
    }
    @Override
    public String getModel() {
        return this.model;
    }

    @Override
    public String getColor() {
        return this.color;
    }

    @Override
    public Integer getHorsePower() {
        return this.horsePower;
    }

    @Override
    public String countryProduced() {
        return this.countryProduced;
    }

    @Override
    public String toString() {
        return String.format("This is %s produced in %s and have %d tires",
                this.getModel(),this.countryProduced(), TIRES);
    }
}
package carShop;

public interface Car {
    public int TIRES = 4;
    public String getModel();
    public String getColor();
    public Integer getHorsePower();
    public String countryProduced();
}

 */