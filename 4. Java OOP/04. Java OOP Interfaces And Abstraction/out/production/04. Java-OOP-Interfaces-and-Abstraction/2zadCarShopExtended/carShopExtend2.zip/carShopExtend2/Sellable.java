package carShopExtend2;

public interface Sellable {
    public Double getPrice();
}
