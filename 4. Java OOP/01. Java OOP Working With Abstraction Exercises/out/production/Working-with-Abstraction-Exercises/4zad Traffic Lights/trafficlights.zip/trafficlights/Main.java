package trafficlights;

import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        TraficLight[] trafficLights
                = Arrays.stream(scanner.nextLine().split("\\s+"))
                .map(TraficLight::valueOf)//vrushta potok ot traffic light enumeracii
                .toArray(TraficLight[]::new);

        int n = Integer.parseInt(scanner.nextLine());

        TraficLight[] lights = TraficLight.values();
        while (n-- > 0) {
            for (int i = 0; i < trafficLights.length; i++) {

                TraficLight trafficLight = trafficLights[i];
                //trafficLights[] == GREEN RED YELLOW
                //trqbva da vida tozi na koito se namiram na koq poziciq e i da vzema sledvashtiq ot enum

                int next = trafficLight.ordinal() + 1;//sledvashtiq vzima rekushtiq + 1
                if(next >= lights.length){
                    next = 0;
                }
                trafficLights[i] = lights[next];
                System.out.print(trafficLights[i] + " ");
            }
            System.out.println();
        }
    }
}

/*

//80 /100
package trafficlights;

import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        TraficLight[] trafficLights
                = Arrays.stream(scanner.nextLine().split("\\s+"))
                .map(TraficLight::valueOf)//vrushta potok ot traffic light enumeracii
                .toArray(TraficLight[]::new);

        int n = Integer.parseInt(scanner.nextLine());
        int counter = 0;
        while (n-- > 0) {
            for (int i = 0; i < trafficLights.length; i++) {

                //trafficLights[] == GREEN RED YELLOW
                //trqbva da vida tozi na koito se namiram na koq poziciq e i da vzema sledvashtiq ot enum
                int currentLightIndexFromEnum = trafficLights[i].ordinal();
                TraficLight[] traficLight = TraficLight.values();
                TraficLight tt = traficLight[(currentLightIndexFromEnum + 1 + counter)%3];
                System.out.print(tt + " ");
            }
            counter++;
            System.out.println();
        }
    }
}

package trafficlights;

public enum TraficLight {
    RED,
    GREEN,
    YELLOW
}

 */