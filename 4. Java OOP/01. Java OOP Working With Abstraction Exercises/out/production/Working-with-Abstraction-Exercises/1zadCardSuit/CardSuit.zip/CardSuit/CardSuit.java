package CardSuit;

public enum CardSuit {
    CLUBS,
    DIAMONDS,
    HEARTS,
    SPADES;
//vsqka duma ima stoinost kato v masiv ot 0 do broq elementi - ordinal
    CardSuit(){

    }
}
