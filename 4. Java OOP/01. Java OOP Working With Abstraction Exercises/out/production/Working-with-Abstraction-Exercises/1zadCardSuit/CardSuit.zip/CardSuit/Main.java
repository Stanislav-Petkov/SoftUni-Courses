package CardSuit;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Card Suits:");
        CardSuit[] values = CardSuit.values();
        for (int i = 0; i < values.length; i++) {
            System.out.printf("Ordinal value: %d; Name value: %s%n",values[i].ordinal(),values[i]);
        }

    }
}
/*
package CardSuit;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Card Suits:");
        CardSuit[] values = CardSuit.values();
        for (int i = 0; i < values.length; i++) {
            System.out.printf("Ordinal value: %d; Name value: %s%n",values[i].ordinal(),values[i]);
        }

    }
}

 */
/*
package CardSuit;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String input = scanner.nextLine();
        System.out.println("Card Suits:");
        for (CardSuit value : CardSuit.values()) {
            System.out.printf("Ordinal value: %d; Name value: %s%n",value.ordinal(),value);
        }
    }
}
 */
/*
100
package CardSuit;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String input = scanner.nextLine();
        System.out.println("Card Suits:");
        System.out.printf("Ordinal value: %d; Name value: %s%n",CardSuit.CLUBS.ordinal(),CardSuit.CLUBS);
        System.out.printf("Ordinal value: %d; Name value: %s%n",CardSuit.DIAMONDS.ordinal(),CardSuit.DIAMONDS);
        System.out.printf("Ordinal value: %d; Name value: %s%n",CardSuit.HEARTS.ordinal(),CardSuit.HEARTS);
        System.out.printf("Ordinal value: %d; Name value: %s%n",CardSuit.SPADES.ordinal(),CardSuit.SPADES);

    }
}
 */
/*
public class Main {
    public static void main(String[] args) {
        System.out.println(CardSuit.CLUBS.ordinal());
        System.out.println(CardSuit.DIAMONDS.ordinal());
        System.out.println(CardSuit.HEARTHS.ordinal());
        System.out.println(CardSuit.SPADES.ordinal());
//0
//1
//2
//3
    }
}


 */
