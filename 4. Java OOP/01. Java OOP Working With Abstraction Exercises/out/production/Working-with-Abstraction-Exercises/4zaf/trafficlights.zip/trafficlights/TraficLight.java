package trafficlights;

public enum TraficLight {
    RED,
    GREEN,
    YELLOW
}
