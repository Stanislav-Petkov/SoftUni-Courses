package cardswithpower;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String type = scanner.nextLine();
        String suit = scanner.nextLine();

        Card card = new Card(CardRank.valueOf(type), CardSuit.valueOf(suit));
        System.out.println(card.toString());
    }
}


/*
1 variant 100

package cardswithpower;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String type = scanner.nextLine();
        String suit = scanner.nextLine();

        Card card = new Card(type, suit);
        System.out.println(card.toString());
    }
}

package cardswithpower;

public class Card {
    private String type;
    private String suit;

    public Card(String type, String suit){
        this.type = type;
        this.suit = suit;
    }

    @Override
    public String toString(){
        return String.format("Card name: %s of %s; Card power: %d"
                ,type,suit,getPower());
    }

    private int getPower() {
        return CardsWithPower.valueOf(type).getValue() + CardSuit.valueOf(suit).getValue();
    }
}

package cardswithpower;

public enum CardSuit {
    CLUBS(0),
    DIAMONDS(13),
    HEARTS(26),
    SPADES(39);

    private final int value;
    CardSuit(int value){
        this.value = value;
    }

    public int getValue() {
        return this.value;
    }
}

package cardswithpower;

public enum CardsWithPower {
    TWO(2),
    THREE(3),
    FOUR(4),
    FIVE(5),
    SIX(6),
    SEVEN(7),
    EIGHT(8),
    NINE(9),
    TEN(10),
    JACK(11),
    QUEEN(12),
    KING(13),
    ACE(14);

    private final int value;
    CardsWithPower(int value){
        this.value = value;
    }

    public int getValue(){
        return this.value;
    }
}

 */