package JediGalaxy.jediGalaxy;

import java.io.File;

public class Galaxy {
    private Filed filed;
    public Galaxy(Filed filed){
        this.filed = filed;
    }

    public void moveSith(int row, int col) {
        while (row >= col && col >= 0) {
            if (filed.isInBounds(row,col)) {//pita dali e v ramkite na reda i na kolonata
                filed.setValue(row,col,0);
            }
            row--;
            col--;
        }

    }

    public long moveJedi(int row, int col) {
        long collectedPower = 0;
        while (row >= 0 && col < this.filed.getColLength(1)) {
            if (this.filed.isInBounds(row,col)) {
                collectedPower += this.filed.getValue(row,col);
            }
            row--;
            col++;
        }
        return collectedPower;
    }
}
//klasa representira logikata v boinoto pole