package implementations;

import interfaces.List;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Iterator;

public class ArrayList<E> implements List<E> {

    private static final int INITIAL_CAPACITY = 4;
    private Object[] elements;
    private int size;
    private int capacity;
    public ArrayList(){
        this.elements = new Object[INITIAL_CAPACITY];
        this.size = 0;
        this.capacity = INITIAL_CAPACITY;
    }
    @Override
    public boolean add(E element) {
        if(this.size == this.capacity){
            grow();
        }
       // this.size++;
        this.elements[this.size++] = element; // postfix ++ se izpulnqva sled kato se e izpulnil celiq red
        return true;
    }

    @Override
    public boolean add(int index, E element) {
        if(!validIndex(index)){
            return false;
        }
        shiftRight(index);//osigurqvam mqsto za elementa
        this.elements[index] = element;
        this.size++;
        return true;
    }

    @Override
    public E get(int index) {
        ensureIndex(index);
        return (E) this.elements[index];
    }

    @Override
    public E set(int index, E element) {
        ensureIndex(index);

        Object existing = this.elements[index];
        this.elements[index] = element;
        return (E) existing;
    }

    @Override
    public E remove(int index) {

        ensureIndex(index);
        Object existing = this.elements[index];
        shiftLeft(index);
        this.size--;
        shrinkIfNeeded();

        return (E) existing;
    }

    private void shrinkIfNeeded() {
        if(this.size > this.capacity / 3){
            return;
        }
        this.capacity /= 2;
        this.elements = Arrays.copyOf(this.elements,this.capacity);
    }

    @Override
    public int size() {
        return this.size;
    }

    @Override
    public int indexOf(E element) {
        for (int i = 0; i < this.size; i++) {
            if(this.elements[i].equals(element)){
                return i;
            }
        }
        return -1;
    }

    @Override
    public boolean contains(E element) {
        return this.indexOf(element) >= 0;
    }

    @Override
    public boolean isEmpty() {
        return this.size == 0;
    }

    @Override
    public Iterator<E> iterator() {
        return new Iterator<E>() {
            private int index = 0;
            @Override
            public boolean hasNext() {
                return index < size();
            }

            @Override
            public E next() {
                return get(index++);
            }
        };
    }

    private void grow() {
        this.capacity *= 2;
        Object[] tmp = new Object[this.capacity];//suzdava nov masiv s 2 puti poveche kletki

        //prehvurlqm vsichki elementi ot elements v tmp

        for (int i = 0; i < this.elements.length; i++) {
            tmp[i] = this.elements[i];
        }
        this.elements = tmp;
    }

    private void shiftRight(int index) {
        //mestq elementite nadqstno
        //ako iskam da dobavq na 2ri index mestq tezi otdqno na nego s 1 nadqsno kato zapochvam ot posledniq
        //[1,2,3,4...]
        //[1,2,3,4,4..]
        //[1,2,3,3,4..]
        //[1,2,new,3,4..]
        for (int i = this.size - 1; i >= index ; i--) {
            this.elements[i + 1] =this.elements[i]; //[1,2,3,4,4..]
        }
    }

    private void shiftLeft(int index) {
        for (int i = index; i < this.size - 1 ; i++) {
            this.elements[i] = this.elements[i + 1];
        }
        //[1,2,3,4]
        //[1,3,4
    }

    private boolean validIndex(int index) {
        return index >= 0 && index < this.size;
    }

    private void ensureIndex(int index) {
        if(!validIndex(index)){
            throw new IndexOutOfBoundsException(
                    "Cannot use index " + index + " on ArrayList with " + this.size + " elements ");
        }
    }
}
