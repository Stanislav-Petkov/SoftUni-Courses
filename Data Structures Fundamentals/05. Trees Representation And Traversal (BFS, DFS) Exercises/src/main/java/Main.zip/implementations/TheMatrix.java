package implementations;

import java.util.ArrayDeque;
import java.util.Deque;

public class TheMatrix {
    private char[][] matrix;
    private char fillChar;
    private char startChar; //tozi koito shte bude zamenqn
    private int startRow;
    private int startCol;

    public TheMatrix(char[][] matrix, char fillChar, int startRow, int startCol) {
        this.matrix = matrix;
        this.fillChar = fillChar;
        this.startRow = startRow;
        this.startCol = startCol;
        this.startChar = this.matrix[this.startRow][this.startCol];
    }

//dfs -> stack
//bfs -> queue

    public void solve() {
        Deque<int[]> deque = new ArrayDeque<>();

        deque.push(new int[]{this.startRow, this.startCol});

        //this.matrix[startRow][startCol] = this.fillChar;
        while (!deque.isEmpty()){
            int[] position = deque.pop();


            int row = position[0];
            int col = position[1];

            this.matrix[row][col] = this.fillChar;
//            System.out.println(this.toOutputString());
//            System.out.println();

            if(isInBounds(row + 1,col) && this.matrix[row + 1][col] == this.startChar){
                deque.push(new int[]{row + 1, col});
            }
            if(isInBounds(row,col + 1) && this.matrix[row][col + 1] == this.startChar){
                deque.push(new int[]{row, col + 1});

            }
            if(isInBounds(row - 1, col) && this.matrix[row - 1][col] == this.startChar){
                deque.push(new int[]{row - 1, col});

            }
            if(isInBounds(row, col - 1) && this.matrix[row][col - 1] == this.startChar){
                deque.push(new int[]{row , col - 1});

            }

        }
    }

    private boolean isInBounds(int row, int col) {
        return !isOutOfBounds(row,col);
    }


    private boolean isOutOfBounds(int row, int col) {
        return row < 0 || row >= this.matrix.length || col < 0 || col >= this.matrix[row].length;
    }

    public String toOutputString() {

        StringBuilder sb = new StringBuilder();
        for (int r = 0; r < this.matrix.length; r++) {
            for (int c = 0; c < this.matrix[r].length; c++) {
                sb.append(this.matrix[r][c]);
            }
            sb.append(System.lineSeparator());
        }
        return sb.toString().trim();
    }

}




/*
drugo reshenie s opashka

package implementations;

import java.util.ArrayDeque;
import java.util.Deque;

public class TheMatrix {
    private char[][] matrix;
    private char fillChar;
    private char startChar; //tozi koito shte bude zamenqn
    private int startRow;
    private int startCol;

    public TheMatrix(char[][] matrix, char fillChar, int startRow, int startCol) {
        this.matrix = matrix;
        this.fillChar = fillChar;
        this.startRow = startRow;
        this.startCol = startCol;
        this.startChar = this.matrix[this.startRow][this.startCol];
    }

//dfs -> stack
//bfs -> queue

    public void solve() {
        //pazi na koi red i kolona sum otishul da ocvetqvam koeto pravi i rekursiqta
        Deque<int[]> coordinates = new ArrayDeque<>();

        //purviq put dobavqm 2 elementa
        coordinates.offer(new int[]{startRow, startCol});

        while (!coordinates.isEmpty()) {
            int[] position = coordinates.poll();

            int row = position[0];
            int col = position[1];

            this.matrix[row][col] = this.fillChar; // v matricata stupkite sa kato v rekursiqta

            System.out.println(this.toOutputString());
            System.out.println();
            //dobavqm vsichki vuzmoji susedi v opashkata
            //row + 1 zapochva ot sledvashtiq element
            if (isInBounds(row + 1, col) && this.matrix[row + 1][col] == this.startChar) {
                coordinates.offer(new int[]{row + 1, col});
            }
            if (isInBounds(row - 1, col) && this.matrix[row - 1][col] == this.startChar) {
                coordinates.offer(new int[]{row - 1, col});
            }
            if (isInBounds(row, col + 1) && this.matrix[row][col + 1] == this.startChar) {
                coordinates.offer(new int[]{row, col + 1});
            }
            if (isInBounds(row, col - 1) && this.matrix[row][col - 1] == this.startChar) {
                coordinates.offer(new int[]{row, col - 1});
            }
        }
    }

    private boolean isInBounds(int row, int col) {
        return !isOutOfBounds(row, col);
    }


    private boolean isOutOfBounds(int row, int col) {
        return row < 0 || col < 0 || this.matrix.length <= row || this.matrix[row].length <= col;

    }

    public String toOutputString() {

        StringBuilder sb = new StringBuilder();
        for (int r = 0; r < this.matrix.length; r++) {
            for (int c = 0; c < this.matrix[r].length; c++) {
                sb.append(this.matrix[r][c]);
            }
            sb.append(System.lineSeparator());
        }
        return sb.toString().trim();
    }

}


 */












/*
package implementations;

public class TheMatrix {
    private char[][] matrix;
    private char fillChar;
    private char startChar; //tozi koito shte bude zamenqn
    private int startRow;
    private int startCol;

    public TheMatrix(char[][] matrix, char fillChar, int startRow, int startCol) {
        this.matrix = matrix;
        this.fillChar = fillChar;
        this.startRow = startRow;
        this.startCol = startCol;
        this.startChar = this.matrix[this.startRow][this.startCol];
    }

    public void solve() {
        //ot kudeto zapochvam da populvam matricata
        fillMatrix(this.startRow,this.startCol);
    }
    private void fillMatrix(int row, int col){
        //duno na rekursitq ako izlqza ot granici na matrica ili ako charactera koito iskam da smenq ne e sushtiq
        if(isOutOfBounds(row,col) || this.matrix[row][col] != this.startChar){
            return;
        }

        //purva staupka e da kaja che startovata poziciq stava ravna na noviq character x
        this.matrix[row][col] = this.fillChar;

        System.out.println(this.toOutputString()); // vseki put shte gledam kak se promenq matricata
        System.out.println();

        //proverqm na kude moje da hodq, shte hodq nadlu i nadqsno nagore i nqlqvo
        this.fillMatrix(row + 1,col); // nadqso
        this.fillMatrix(row, col + 1); //nadolu
        this.fillMatrix(row - 1, col); //nagore
        this.fillMatrix(row, col -1); // nalqvo

    }


    private boolean isOutOfBounds(int row, int col){
        return row < 0 || row >= this.matrix.length || col < 0 || col >= this.matrix[row].length;
    }
    public String toOutputString() {
        StringBuilder sb = new StringBuilder();
        for (int r = 0; r < this.matrix.length; r++) {//vsichki elementi na redovete
            for (int c = 0; c < this.matrix[r].length; c++) {
                 sb.append(this.matrix[r][c]);
            }
            sb.append(System.lineSeparator());
        }
        return sb.toString().trim();//trim e za da nqma dopulnitelene nov red nakrq
    }
}
 */
