package implementations;

import interfaces.AbstractTree;

import java.util.*;
import java.util.stream.Collectors;

public class Tree<E> implements AbstractTree<E> {
    private E key;
    private Tree<E> parent;
    private List<Tree<E>> children;

    public Tree(E key) {  //moje da ima poveche ot edno dete ili nikolkot , Tree<E>... children
        this.key = key;
        this.children = new ArrayList<>();
        //       this.children.addAll(Arrays.asList(children));
//        for (int i = 0; i < children.length; i++) {
//            children[i].setParent(this);
//        }
    }

    public Tree() {
        this.children = new ArrayList<>();
    }


    @Override
    public void setParent(Tree<E> parent) {
        this.parent = parent; // na tekushtiq obekt v konstruktora children[i] roditelq stava podadaeniq roditel
    }

    @Override
    public void addChild(Tree<E> child) {
        this.children.add(child);
    }

    @Override
    public Tree<E> getParent() {
        return this.parent;
    }

    @Override
    public E getKey() {
        return this.key;
    }

    @Override
    public String getAsString() {
        StringBuilder builder = new StringBuilder();

        buildWithRecurrence(builder, 0, this);

        return builder.toString().trim();
    }

    public String straverseWithBFS() {
        StringBuilder builder = new StringBuilder();
        int ident = 0;
        Deque<Tree<E>> deque = new ArrayDeque<>();

        deque.offer(this);
        while (!deque.isEmpty()) {
            Tree<E> tree = deque.poll();

            if (tree.getParent() != null) {
                ident = 2;
            }
            if (tree.children.size() == 0 && tree.parent.getParent() != null) {///ako elementa e listo
                ident = 4;
            }
            builder.append(this.getPadding(ident))
                    .append(tree.getKey())
                    .append(System.lineSeparator());

            for (Tree<E> child : tree.children) {
                deque.offer(child);
            }
        }
        return builder.toString().trim();
    }


    private void buildWithRecurrence(StringBuilder builder, int ident, Tree<E> tree) {

        builder.append(this.getPadding(ident))
                .append(tree.key)
                .append(System.lineSeparator());

        for (Tree<E> child : tree.children) {
            buildWithRecurrence(builder, ident + 2, child);
        }
    }

    private String getPadding(int size) {
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < size; i++) {
            builder.append(" ");
        }
        return builder.toString();
    }

    public List<Tree<E>> getLeafKyesWithBfs() { //vrushta vsichki nodove
        Deque<Tree<E>> deque = new ArrayDeque<>();

        deque.offer(this);

        List<Tree<E>> allNodes = new ArrayList<>();

        while (!deque.isEmpty()) {
            Tree<E> currentTree = deque.poll();
            allNodes.add(currentTree);
            for (Tree<E> tree : currentTree.children) {
                deque.offer(tree);
            }
        }
        return allNodes;
    }

    @Override
    public List<E> getLeafKeys() {
        return getLeafKyesWithBfs().stream()
                .filter(tree -> tree.children.size() == 0)
                .map(Tree::getKey)
                .collect(Collectors.toList());

    }

    private List<Tree<E>> traverseTreeWithRecurrence(List<Tree<E>> collection, Tree<E> tree) {
        collection.add(tree);
        for (Tree<E> currentNode : tree.children) {
            traverseTreeWithRecurrence(collection, currentNode);
        }
        return collection;
    }

    @Override
    public List<E> getMiddleKeys() {
        ArrayList<Tree<E>> allKeys = new ArrayList<>();
        this.traverseTreeWithRecurrence(allKeys, this);
        return allKeys.stream()
                .filter(tree -> tree.children.size() > 0 && tree.parent != null)
                .map(Tree::getKey)
                .collect(Collectors.toList());

    }

    @Override
    public Tree<E> getDeepestLeftmostNode() {
        ////s DFS
        List<Tree<E>> deepestLeftMostNode = new ArrayList<>();
        deepestLeftMostNode.add(new Tree<>());
        int[] maxPath = new int[1];
        int max = 0;

        findDeepestNodeDFS(deepestLeftMostNode, maxPath, max, this);

        return deepestLeftMostNode.get(0);
    }
    private void findDeepestNodeDFS(List<Tree<E>> deepestLeftMostNode, int[] maxPath, int max, Tree<E> tree) {
        //max++; //tekushtiq maximum koito imam do momenta
        if(max > maxPath[0]){
            maxPath[0] = max;
            deepestLeftMostNode.set(0,tree);//setvam tekushtiq nai dulbok node
        }
        for(Tree<E> child : tree.children){
            findDeepestNodeDFS(deepestLeftMostNode,maxPath,max + 1,child);
        }
    }



//    public Tree<E> getDeepestLeftmostNode() {
    //s bfs
//        List<Tree<E>> allNodes = getLeafKyesWithBfs();
//
//        int maxPath = 0;
//        Tree<E> deepestLeftMostLeaf = null;
//        for(Tree<E> tree : allNodes){
//            if(tree.isLeaf()){
//                int currentPath = getStepsFromLeafToRoot(tree);
//                if(currentPath > maxPath){
//                    maxPath = currentPath;
//                    deepestLeftMostLeaf = tree;
//                }
//            }
//        }
//        return deepestLeftMostLeaf;
//    }

    private int getStepsFromLeafToRoot(Tree<E> tree) {
        int counter = 0;
        Tree<E> current = tree;
        while (current.parent != null) {
            counter++;
            current = current.parent;
        }
        return counter;
    }

    private boolean isLeaf() {
        return this.children.size() == 0 && this.parent != null;
    }

    @Override
    public List<E> getLongestPath() {
        //da prezapisvam spisuka vseki put kogato namerq poveche elementi
        List<List<E>> longestPathNodes = new ArrayList<>();
        longestPathNodes.add(new ArrayList<>());
        int[] maxPath = new int[1];
        int max = 0;

        findLongestPathDFS(longestPathNodes, maxPath, max, this);
        int maxVal = Integer.MIN_VALUE;
        int counter = 0;
        int i;
        List<E> maxList = new ArrayList<>();
        for (i = 0; i < longestPathNodes.size(); i++) {
            if(maxVal < longestPathNodes.get(i).size()){
                maxVal = longestPathNodes.get(i).size();
                counter = i;
                maxList = new ArrayList<>(longestPathNodes.get(i));
            }
        }
        Collections.reverse(maxList);
        return maxList;
        //return longestPathNodes.get(counter);
    }

    private void findLongestPathDFS(List<List<E>> longestPathNodes, int[] maxPath, int max, Tree<E> tree) {
        if (max > maxPath[0]) {
            maxPath[0] = max;
        }

       // int counter = 0;
        Tree<E> current = tree;
        if(tree.isLeaf()) {
            List<E> currentList = new ArrayList<>();
            while (current != null) {
                //counter++;
                currentList.add(current.key);
                current = current.parent;
            }
            longestPathNodes.add(currentList);
        }

//        if( maxPath[0] < max){
//            List<E> newLongestPathNodes = new ArrayList<>();
//            for (int i = 0; i < longestPathNodes.size(); i++) {
//                newLongestPathNodes.add(longestPathNodes.get(i));
//            }
//        }
        for (Tree<E> child : tree.children) {
            findLongestPathDFS(longestPathNodes, maxPath, max + 1, child);
        }
    }



    @Override
    public List<List<E>> pathsWithGivenSum(int sum) {
        List<List<E>> allPaths = new ArrayList<>();
        List<List<E>> pathsWithGivenSum = new ArrayList<>();
        //longestPathNodes.add(new ArrayList<>());
        int[] maxPath = new int[1];
        int max = 0;

        findLongestPathDFS(allPaths, maxPath, max, this);
        int maxVal = Integer.MIN_VALUE;
        int counter = 0;
        int i;
        List<E> maxList = new ArrayList<>();
        for (i = 0; i < allPaths.size(); i++) {
            List<E> currentPath = allPaths.get(i);
            int currentSum =0;
            for (int j = 0; j < currentPath.size(); j++) {
                currentSum = currentSum + Integer.parseInt(String.valueOf((int)currentPath.get(j)));
            }
            if(currentSum == sum){
                Collections.reverse(currentPath);
                pathsWithGivenSum.add(currentPath);
            }
//            if(maxVal < pathWithGivenSum.get(i).size()){
//                maxVal = pathWithGivenSum.get(i).size();
//                counter = i;
//                maxList = new ArrayList<>(pathWithGivenSum.get(i));
//            }
        }
        //Collections.reverse(maxList);
        return pathsWithGivenSum;
    }

    @Override
    public List<Tree<E>> subTreesWithGivenSum(int sum) {
        return null;
    }
}



/*

    @Override
    public String getAsString() {
        StringBuilder builder = new StringBuilder();//tove e bufer v koito shte pazq tekushtiq red
        //do koito e stignalo

        //podavam kolko spacea ili ot koi level trugvam, trugvam ot 0leviq red
        //podvam nodea vseki put kato obhojda trqbva da znae na koi node se namira i na kude da pogledne
        //podavam this koeto e durvoto koeto vurnah pri suzdavaneto
        traverseTreeWithRecurrence(builder, 0, this);

        return builder.toString().trim();
    }

    private void traverseTreeWithRecurrence(StringBuilder builder
            , int indent, Tree<E> tree) {

        builder.append(this.getPadding(indent)) // pechata spaceove sprqmo nivoto na koeto se namira v nachaloto e 0
                // i sled dova klucha i nov red
                .append(tree.getKey())
                .append(System.lineSeparator());
        for (Tree<E> child : tree.children) { //na tekushtotot durvo s koeto sum izvikal rekursiqta negovite deca
            traverseTreeWithRecurrence(builder, indent + 2, child);
        }
        //ako veche nqmam deca v tekushtiq node return nqma da se izpulni fora i stiga duno na rekursiqta

    }

    private String getPadding(int size) {
        StringBuilder stringBuilder = new StringBuilder();
        for (int i = 0; i < size; i++) {
            stringBuilder.append(" ");
        }
        return stringBuilder.toString();
    }

 ///////////////////////////////////
 /////////////////////////////////////
    public List<Tree<E>> getLeafKyesWithBfs() {

        StringBuilder builder = new StringBuilder();
        Deque<Tree<E>> queue = new ArrayDeque<>();

        queue.offer(this);

        int ident = 0;

        List<Tree<E>> allNodes = new ArrayList<>();
        while (!queue.isEmpty()) {

            Tree<E> tree = queue.poll();
            allNodes.add(tree);
            for (Tree<E> child : tree.children) {
                queue.offer(child);
            }
        }
        //leaf nqma descendants naslednici, vrushta vsichki nodove i gleda koit nqma naslednici
        //vrushta samo nodove s deca razmer 0

        return allNodes;
    }

    @Override
    public List<E> getLeafKeys() {

        return getLeafKyesWithBfs()
                .stream()
                .filter(tree -> tree.children.size() == 0)
                .map(Tree::getKey)//mapni gi kato na vseki edin mu vzemesh klucha
                .collect(Collectors.toList());
    }

    private List<Tree<E>> traverseTreeWithRecurrence(List<Tree<E>> collection, Tree<E> tree) {
        collection.add(tree); // dobavq tekushtoto durvo koeto iterira
        for (Tree<E> child : tree.children) {
            traverseTreeWithRecurrence(collection, child);
        }
        return collection;
    }

    @Override
    public List<E> getMiddleKeys() {
        List<Tree<E>> allNodes = new ArrayList<>();
        this.traverseTreeWithRecurrence(allNodes, this); //vzima vsichki durveta
        return allNodes.stream()
                .filter(tree -> tree.children.size() > 0 && tree.parent != null)
                .map(Tree::getKey)
                .collect(Collectors.toCollection(ArrayList::new));

    }

    @Override
    public Tree<E> getDeepestLeftmostNode() {
        //bottom up approach
        //broq kolko stupki ima ot vsqko edno listo do vseki edin ot parentite mu
        List<Tree<E>> trees = this.getLeafKyesWithBfs();

        int maxPath = 0;
        Tree<E> deepestLeftMostNode = null;
        for (Tree<E> tree : trees) {
            if (tree.isLeaf()) {
               int currentPath =  getStepsFromLeafToRoot(tree);
               if(currentPath > maxPath){
                    maxPath = currentPath;
                   deepestLeftMostNode = tree;
               }
            }
        }

        return deepestLeftMostNode;
    }

    private int getStepsFromLeafToRoot(Tree<E> tree) {

        int counter = 0;
        Tree<E> current = tree;
        while (current.parent != null){
            counter++;
            current = current.parent;
        }
        return counter;

        //pechata kolko stupki ima ot vseki leaf do roota kato
        //zapochva po bfs ot 2roto nivo na durvoto i produljava nadolu
    }

    private boolean isLeaf() {
        return this.children.size() == 0 && this.parent != null;
    }



//////////////////////////////////////
/////////////////////////////////////////
/////////////////////////////////////////
 @Override
    public Tree<E> getDeepestLeftmostNode(){
        ////s DFS

        List<Tree<E>> deepestLeftMostNode = new ArrayList<>();
        int[] maxPath = new int[1];

        deepestLeftMostNode.add(new Tree<E>());
        int max = 0;

        findDeepestNodeDFS(deepestLeftMostNode,maxPath,max,this);

        return deepestLeftMostNode.get(0);
    }

    private void findDeepestNodeDFS(List<Tree<E>> deepestLeftMostNode, int[] maxPath, int max, Tree<E> tree) {
        //max++; //tekushtiq maximum koito imam do momenta
        if(max > maxPath[0]){
            maxPath[0] = max;
            deepestLeftMostNode.set(0,tree);//setvam tekushtiq nai dulbok node
        }
        for(Tree<E> child : tree.children){
            findDeepestNodeDFS(deepestLeftMostNode,maxPath,max + 1,child);
        }

        //kogato iskam da imam uvelichavane v rekursiq podavam kopie max + 1
        //kogato ne iskam da se promenqt podavam masivi koito ne se promenqt int[] maxPath
        //masiva polzva edna i sushta referenciq
        // a max vse edno vseki put se suzdava na novo


    }


//    public Tree<E> getDeepestLeftmostNode() {
    //s bfs
//        List<Tree<E>> allNodes = getLeafKyesWithBfs();
//
//        int maxPath = 0;
//        Tree<E> deepestLeftMostLeaf = null;
//        for(Tree<E> tree : allNodes){
//            if(tree.isLeaf()){
//                int currentPath = getStepsFromLeafToRoot(tree);
//                if(currentPath > maxPath){
//                    maxPath = currentPath;
//                    deepestLeftMostLeaf = tree;
//                }
//            }
//        }
//        return deepestLeftMostLeaf;
//    }

 */