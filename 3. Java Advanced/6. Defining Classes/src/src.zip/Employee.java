public class Employee {
    private String name;
    private double salary;
    private String position;
    private String department;
    private String email;
    private int age;

    public Employee(String name, double salary, String position, String department){
        this.name = name;
        this.salary = salary;
        this.position = position;
        this.department = department;
        this.email = "n/a";// default values
        this.age = -1;
    }
    public Employee(String name, double salary, String position, String department, String email){
        this(name, salary, position, department);
        this.email = email;
    }

    public Employee(String name, double salary, String position, String department, int age){
        this(name, salary, position, department);
        this.age = age;
    }
    public Employee(String name, double salary, String position, String department, String email, int age){
        this(name, salary, position,department,email);//vikni konstrukto koito priema purvite nqkolko parametura String name, double salary, String position, String department
        this.age = age;
    }

    public double getSalary(){
        return salary;
    }

    @Override
    public String toString(){
        return String.format("%s %.2f %s %d", this.name, this.salary, this.email, this.age);
    }
}


/*



 public Employee(String name, double salary, String position, String department){
        this.name = name;
        this.salary = salary;
        this.position = position;
        this.department = department;
    }


//vikni konstrukto koito priema purvite nqkolko parametura String name, double salary, String position, String department
    //i inicializira ostanalite 2 parametura
    //this();//konstruktor chaining kato vikna konstruktor sus vsichkite poleta i minava
    //purvo prez gorniq konstruktor s 4 polete i posle prez dolnia za drugite 2 poleta
    public Employee(String name, double salary, String position, String department, String email, int age){
        this(name, salary, position,department);//vikni konstrukto koito priema purvite nqkolko parametura String name, double salary, String position, String department
        this.email = email;
        this.age = age; //i inicializira ostanalite 2 parametura
    }

 */