import java.util.*;

public class Department {
    private String name;
    private List<Employee> employees;

    public Department(String name){
        this.name = name;
        this.employees = new ArrayList<>();// tezi employeeta sa nov spisuk ot slujiteli
        ///inicializiram si strukturata ot danni
    }

    public String getName(){
        return this.name;
    }

    public List<Employee> getEmployees(){
        return this.employees;
    }

    public double getAverageSalary(){//vzima sredno aritmetichno na zaplati na slujiteli
        return this.employees
                .stream()
                .mapToDouble(Employee::getSalary) //ot Employee clasa vika getSalary metoda veche rabotq s double
                 //promenq tipa na purvonachalnite danni kum doble
                .average()// broi kolko sa .mapToDouble(Employee::getSalary) i im vsima sredno aritmetichno
                .orElse(0.0);
    }
}
