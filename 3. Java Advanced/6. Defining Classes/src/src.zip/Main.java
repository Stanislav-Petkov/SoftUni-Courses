import java.util.*;
import java.util.regex.Matcher;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int n = Integer.parseInt(scanner.nextLine());
        // imena na departamenti
        Map<String, Department> departments = new HashMap<>();
        while (n-- > 0) {
            String[] tokens = scanner.nextLine().split("\\s+");
            String name = tokens[0];
            double salary = Double.parseDouble(tokens[1]);
            String position = tokens[2];
            String departament = tokens[3];

            Employee employee;
            if (tokens.length == 4) {
                employee = new Employee(name, salary, position, departament);//suzdava employee s nai bazoviq konstruktor
            } else if (tokens.length == 6) {
                employee = new Employee(name, salary, position, departament,
                        tokens[4], Integer.parseInt(tokens[5]));
            } else {
                try {
                    int age = Integer.parseInt(tokens[4]);//opitai se da parsnesh tokens ot 4
                    //ako uspeesh suzdai obekta s konstruktor tozi:
                    employee = new Employee(name, salary, position, departament, age);
                } catch (NumberFormatException e) {                  //  email
                    employee = new Employee(name, salary, position, departament, tokens[4]);
                }
            }
            departments.putIfAbsent(departament, new Department(departament));
            //dobavqm slujitelq
            //vzemi tekushtiq departament na nego mu vzemi slujitelite i dobavi slujitelq
            departments.get(departament).getEmployees().add(employee);
        }
        Department maxDepartment = departments
                .entrySet()
                .stream()
                .max(Comparator.comparingDouble(f -> f.getValue().getAverageSalary()))
                .get()  //vrushta entryto string i value
                .getValue(); // departamenta
        // tova beshe : .max((f,s) -> {
        //                    return f.getValue().getAverageSalary() - s.getValue().getAverageSalary();
        //                })

        System.out.println("Highest Average Salary: " + maxDepartment.getName());

        //otpechatva slujitelite : e
        maxDepartment.getEmployees()
                .stream()
                .sorted((f,s) -> Double.compare(s.getSalary(),f.getSalary()))//sortira gi po zaplata
                .forEach(System.out::println);

        //tova beshe maxDepartment.getEmployees().forEach(e -> {
        //            System.out.println(e);
        //
        //        });


    }
}


/*
kato beshe s set a ne s map

departments.add(new Department(departament));
            for(Department dept : departments){
                if(dept.getName().equals(departament)){//na departamenta imeto iskam da e ravno na tekushtoto ime
                    //koeto sum prochel ot konzolata
                    //ako sum v tozi departament mu vzimam valueto koeto e lista
                    dept.getEmployees().add(employee); // dept.getEmployees() vrushta list v koito dobavaem employee
                }
            }
 */