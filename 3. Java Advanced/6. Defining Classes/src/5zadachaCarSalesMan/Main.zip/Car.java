public class Car {
    private String model;
    private Engine engine;
    private int weight;
    private String color = "n/a";

    public Car(String model, Engine engine) {
        this.model = model;
        this.engine = engine;
        this.weight = -1;
        this.color = "n/a";
    }

    public Car(String model, Engine engine, int weight) {
        this(model, engine);
        this.weight = weight;
    }

    public Car(String model, Engine engine, String color) {
        this(model, engine);
        this.color = color;
    }

    public Car(String model, Engine engine, int weight, String color) {
        this(model, engine, weight);
        this.color = color;
    }

    public String displayModel() {
        return String.format("%s :%n", model);
    }

//    FordFocus:
//    V4-33:
//    Power: 140         // idva ot Engine clasa ot negoviq toString metod
//    Displacement: 28   // idva ot Engine clasa ot negoviq toString metod
//    Efficiency: B      // idva ot Engine clasa ot negoviq toString metod
//    Weight: 1300
//    Color: Silver


    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder(this.model + ":");//append modela
        builder.append(System.lineSeparator())   //apend new line
                .append(this.engine.toString())         // vzim toString metoda ot klasa Engine
                .append(System.lineSeparator())
                .append("Weight: ")       // vikam tochkata na predniq builder i appendvam kum predishniq resultat
                .append(this.weight == -1 ? "n/a" : String.valueOf(this.weight))
                .append(System.lineSeparator())
                .append("Color: ")
                .append(this.color);

        return builder.toString();
    }
}

/*
//drug variant
 @Override
    public String toString(){
        StringBuilder builder = new StringBuilder(this.model + ":");//append modela
        builder.append(System.lineSeparator());//apend new line
        builder.append(this.engine.toString());// vzim toString metoda ot klasa Engine
        builder.append("Weight: " + this.weight);
        builder.append(System.lineSeparator());
        builder.append("Color: " + this.color);
        builder.append(System.lineSeparator());
        return builder.toString();
    }
 */

