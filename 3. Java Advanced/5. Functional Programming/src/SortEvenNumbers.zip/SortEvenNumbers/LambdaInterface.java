package SortEvenNumbers;

import java.util.List;

@FunctionalInterface
public interface LambdaInterface  {
    List<Integer> getEvenNumbers(List<Integer> nums);
}
