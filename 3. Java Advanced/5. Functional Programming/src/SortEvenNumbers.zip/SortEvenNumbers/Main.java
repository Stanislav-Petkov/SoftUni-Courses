package SortEvenNumbers;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] numbs = scanner.nextLine().split(", ");
        List<Integer> numbers = new ArrayList<>();
        for (int i = 0; i < numbs.length; i++) {
            numbers.add(Integer.parseInt(numbs[i]));
        }


        LambdaInterface getEvenNumbersAsList = new LambdaInterface() {
            @Override
            public List<Integer> getEvenNumbers(List<Integer> nums) {
                List<Integer> even = new ArrayList<>();
                for (int i = 0; i < nums.size(); i++) {
                    if (nums.get(i) % 2 == 0) {
                        // System.out.print(nums.get(i) + ", ");
                        even.add(nums.get(i));
                    }
                }
                return even;
            }
        };

        List<Integer> even = getEvenNumbersAsList.getEvenNumbers(numbers);
        StringBuilder stringBuilder = new StringBuilder();
        String separator = "";
        for (int i = 0; i < even.size(); i++) {
            stringBuilder.append(separator);
            stringBuilder.append(even.get(i));
            separator = ", ";
        }
        System.out.println(stringBuilder);

        LambdaInterface sortEvenNumber = new LambdaInterface() {
            @Override
            public List<Integer> getEvenNumbers(List<Integer> evenNumbers) {
                List<Integer> sorted = evenNumbers.stream().sorted().collect(Collectors.toList());
                return sorted;
            }
        };
        List<Integer> sorted = sortEvenNumber.getEvenNumbers(even);
        StringBuilder sortBuilder = new StringBuilder();
        String separator1 = "";
        for (int i = 0; i < sorted.size(); i++) {
            sortBuilder.append(separator1);
            sortBuilder.append(sorted.get(i));
            separator1 = ", ";
        }
        System.out.println(sortBuilder);
        //}
//    public static List<Integer> IAcceptLambda(LambdaInterface lambda){
//        List<Integer> even = new ArrayList<>();
//        for (int i = 0; i < x.size(); i++) {
//            if (x.get(i) % 2 == 0) {
//                System.out.print(x.get(i) + ", ");
//                even.add(x.get(i));
//            }
//        }
//        return even;
//    }
    }
}

//        int counter = 0;
//        List<Integer> even = new ArrayList<>();
//        for (int i = 0; i < numbers.length; i++) {
//            if(numbers[i] % 2 == 0){
//                System.out.print(numbers[i] + ", ");
//                counter++;
//                even.add(numbers[i]);
//            }
//        }
//        System.out.println();
//       List<Integer> sorted = even.stream().sorted().collect(Collectors.toList());
//        for (int i = 0; i < sorted.size(); i++) {
//            System.out.print(sorted.get(i) + ", ");
//        }
/*

package SortEvenNumbers;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] numbs = scanner.nextLine().split(", ");
        Integer[] numbers = new Integer[numbs.length];
        for (int i = 0; i < numbers.length; i++) {
            numbers[i] = Integer.parseInt(numbs[i]);
        }

        int counter = 0;
        List<Integer> even = new ArrayList<>();
        for (int i = 0; i < numbers.length; i++) {
            if(numbers[i] % 2 == 0){
                System.out.print(numbers[i] + ", ");
                counter++;
                even.add(numbers[i]);
            }
        }
        System.out.println();
       List<Integer> sorted = even.stream().sorted().collect(Collectors.toList());
        for (int i = 0; i < sorted.size(); i++) {
            System.out.print(sorted.get(i) + ", ");
        }


    }
}



 */