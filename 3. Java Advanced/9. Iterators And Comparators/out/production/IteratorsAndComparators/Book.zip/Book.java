import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class Book implements Comparable<Book> {
    private String title;
    private int year;
    private List<String> autors;

    public Book(String title, int year, String... authors){
        this.setTitle(title);
        this.setYear(year);
        this.setAutors(authors);
    }

    public void setTitle(String title) {
        this.title = title;
    }
    public void setYear(int year){
        this.year = year;
    }
    public void setAutors(String... authors){
        List<String> newAuthors = new ArrayList<>();
        for (String author : authors){
            newAuthors.add(author);
        }
        this.autors = newAuthors;
    }
    //gorniq metod moje da se napishe i taka
//    public void setAuthors(String... authors){
//        this.autors = new ArrayList<>(Arrays.asList(authors));
//    }
    //moje i taka
//    public void setAutors(String... authors){
//        List<String> newAuthors = Arrays.asList(authors);
//        this.autors = new ArrayList<>(newAuthors);
//    }
    //moje i taka
//    public void setAutors(String... autors){
//        this.autors = Arrays.asList(autors);
//    }

    public List<String> getAutors(){
        return autors;
    }
    public String getTitle(){
        return title;
    }
    public int getYear(){
        return year;
    }

    //Book have to be compared by title. When title is equal, compare them by year.
    public int compareTo(Book book){
        if(this.getTitle().compareTo(book.getTitle()) == 0){
            if(this.getYear() == book.getYear()){
                return 0;
            }else if(this.getYear() > book.getYear()){
                return 1;
            }else {
                return -1;
            }
        }else if(this.getTitle().compareTo(book.getTitle()) > 0){
            return 1;
        }else {
            return -1;
        }
    }


}
