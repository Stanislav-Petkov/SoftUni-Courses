import java.util.Iterator;

public class Library implements Iterable<Book> {

    private Book[] books;

    public Library(Book... books) {
        this.books = books;
    }

    @Override
    public Iterator<Book> iterator() {
        return new LibIterator(books); // poluchava knigite ot klasa Library koito veche gi ima
        // az garantiram che te sa suzdadeni zashtoto v konstruktora se inicializirat this.books = books;
    }

    public static class LibIterator implements Iterator<Book> {
        private Book[] books;
        private int nextIndex;

        //klasut kato go suzdam kazvam int nextIndex = 0; tova e nula

        LibIterator(Book[] books) {//davam na klasa celiq spisuk kato referenciq
            this.nextIndex = 0;// tova e lokaciqta v pametta v koqto che pazim do kude sme stignali
            this.books = books;
        }

        @Override
        public boolean hasNext() {
            return nextIndex < books.length; //ako sledvashtiq indeks e po maluk ot knigite ima next ako ne nqma next
        }
        //tozi metod e kato ot for cikul tova nextIndex < testList.size();


        //        List<String> testList ;
//        for(int nextIndex = 0; nextIndex < testList.size(); nextIndex++)

        @Override
        public Book next() {
            Book book = books[nextIndex]; // vzima knigara
            nextIndex = nextIndex + 1;    // mesti indeksa s 1 npred
            return book;                  // vrushta knigata
        }
    }
}
