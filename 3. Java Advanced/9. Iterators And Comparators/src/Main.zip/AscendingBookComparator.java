import java.util.Comparator;
public class AscendingBookComparator implements Comparator<Book> {
    //klas koito nqmqme kontrol nad nego ne mojem da go napravim comparable

    //Comparable sravnqva tekshtiq obekt s tozi koito mu dava
    //Comparator srqvnqva 2 obekta i vrushta po golemq ot tqh - predostavq logikata dali 2ta obekta sa ravni po golemi ili po malki

    //poneje sum v klas BookComparato ne moga da kaja sravnimi this.year zashtoto nqma this, ima samo 2 knigi
    @Override
    public int compare(Book first, Book second){
        if(first.getTitle().compareTo(second.getTitle()) == 0) {
            if(first.getYear() == second.getYear()){
                return 0;
            }else if(first.getYear() > second.getYear()){
                return 1;
            }else {
                return -1;
            }
        }else if(first.getYear() > second.getYear()){
            return 1;
        }else {
            return -1;
        }
    }
}

//else if(first.getYear() > second.getYear()) {// srtira po godina
///else if(first.getAutors().size() > second.getAutors().size()){ //sortirame po broq na avtorite

/*

 @Override
    public int compare(Book first, Book second){
        if(first.getAutors().size() == second.getAutors().size()){
            return 0; // knigite sa ravni
        } else if(first.getAutors().size() > second.getAutors().size()) {// srtira po godina
            return 1; // purvoto e po golqmo ot vtoroto
        }else { //(first.getYear() < second.getYear())
            return  -1;
        }
        //ne ostava drug sluchai osven first.getYear() < second.getYear()
    }

 */