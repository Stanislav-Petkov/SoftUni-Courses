package ListIterator;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class ListlyIterator {
    private List<String> elements;
    private int index;

    public ListlyIterator(String... values){
        this.elements = Arrays.asList(values);
        this.index = 0;
    }

    public boolean move(){

        if(this.index == this.elements.size() - 1){
            return false; // ne moje da se mesti natatuk ako indeksa sochi posledniq element
        }
        this.index++;
        return true;
        //return this.index <= this.elements.size() - 1;
        // ne trabva da stava raven na size zashtoto tam e sled kraq na lista
    }
    public boolean hasNext(){
        return this.index < this.elements.size() - 1; // ako indeksa e po maluk ot predposledniq element na lista
        //ima na kude da se mesti s oshte 1 do posledniq i vrushta tru inache vrushta falsse
    }

    public void print(){
        if(this.elements.size() == 0) {
            System.out.println("Invalid Operation!");
        }else {
            System.out.println(this.elements.get(index));
        }

    }
}

/*
moi opit
public class ListyIterator implements Iterator<String> {
    private String firstElement;
    private List<String> list;
    private int currentIndex;
    private int nextIndex;

    public ListyIterator(List<String> list){
        this.nextIndex = 0;
        this.list = list;
    }
    public boolean move(){
        if(this.next() != null) {
            this.nextIndex = nextIndex + 1;
            return true;
        }
        return false;
    }
    @Override
    public boolean hasNext() {
        return nextIndex < list.size();
    }

    @Override
    public String next() {
        String nextStr = list.get(nextIndex);
        nextIndex = nextIndex + 1;
        return nextStr;
    }

    public String print(){
        if(this.list.isEmpty()){
            return "Invalid Operation";
        }else {
            return list.get(this.currentIndex);
        }
    }
}
 */