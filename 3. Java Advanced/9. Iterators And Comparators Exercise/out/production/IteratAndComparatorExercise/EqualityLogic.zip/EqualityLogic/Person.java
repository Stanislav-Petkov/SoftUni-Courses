package EqualityLogic;

import java.util.Objects;

public class Person implements Comparable<Person>{
    String name;
    int age;
    public Person(String name, int age){
        this.name=name;
        this.age=age;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    @Override
    public int hashCode(){
        return (this.name.hashCode() + Integer.hashCode(age)) * 73;// za da garantiram unikalnost an hashcoda go umnojavame
        //po prime number
        //kato dobavqsh v heshirana struktura ot danni na obekta mu trqbva kak da si preizchisli hashcoda
        //kogato se poluchi koliziq na hashcoda se izvikva equals() za da kaje dali dvata obekta sa ravni i zatova imat ednakuv h
        //hashcod ili dvata obekta sa razlichni i ima kolizi na hashcoda i tova trqbva da bude zapisano nqkude drugade v tablica
    }

    @Override
    public boolean equals(Object other) {
        if(this == other){ // ako stringovete sa ravni kato referencii pametta
            //im  e edna i sushta  znaci sa ednakvi
            return true;
        }
        //if(o instanceof Person){ //ako obekta e instanciq na person klasa
//to togava obekta e ot tozi tip


        if(other.getClass().getSimpleName().equals(Person.class.getSimpleName())){
//ako na object o imeto e Person

            Person second = (Person) other;
            return this.name.equals(second.name) && this.age == second.age;
        }
        return false;

    }
    //sravnqvam 2 obekta dali edni i sushti 1 person e 1 i susht
    // ako i imeto i age sa ednakvi



    @Override
    public int compareTo(Person other) {
        //sravni this i other
        int result = this.name.compareTo(other.name);
        if(result == 0){//na gorniq red gi sravnqva po imena , ako sa im ednakvi imenata gi sravnqva po age
            result = this.age - other.age; // ako ne sa ednakvi prisvoqva novata stoinost
        }
        return result;
    }

    //    @Override
//    public boolean equals(Object o){
//        if(this == 0){
//
//        }
//    }
}
