package StrategyPattern;

import java.awt.desktop.SystemSleepEvent;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = Integer.parseInt(scanner.nextLine());

        Set<Person> byName = new TreeSet<>(new CompareByName());
        Set<Person> byAge = new TreeSet<>(new PersonComparatorByAge());
        while (n-- > 0){
            //vzimam celiq red i go vrushtam kato person
            //imam potok ot stingove koito trqbva da se mapne
            String[] tokens = scanner.nextLine().split("\\s+");
            String name = tokens[0];
            int age =Integer.parseInt(tokens[1]);
            Person person = new Person(name,age);
            //dobavqme personite v 2 lista i gi sortirame po razlichni pokazateli name i age

            byName.add(person);
            byAge.add(person);
        }                        //strategiqta e otgovornost na tozi obekt v CompareByName
        byName.forEach(System.out::println);
        byAge.forEach(System.out::println);
    }
}

/*
compare by age
byAge.stream().sorted((f, s) -> {
            int result = f.getAge() - s.getAge();
            return result;
        })
                .forEach(System.out::println);

 */


/*

package StrategyPattern;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = Integer.parseInt(scanner.nextLine());

        List<Person> byName = new ArrayList<>();
        List<Person> byAge = new ArrayList<>();
        while (n-- > 0){
            //vzimam celiq red i go vrushtam kato person
            //imam potok ot stingove koito trqbva da se mapne
            String[] tokens = scanner.nextLine().split("\\s+");
            String name = tokens[0];
            int age =Integer.parseInt(tokens[1]);
            Person person = new Person(name,age);
            //dobavqme personite v 2 lista i gi sortirame po razlichni pokazateli name i age

            byName.add(person);
            byAge.add(person);
        }
        byName.stream().sorted((f, s) -> {                                   //sorted priema comparator
            int result = f.getName().length() - s.getName().length();

            // ako sa ravni gi sravnqvame samo po case insensitive v ifa
            //samo na purviq character i zatova i dvata charactera se pravqt v ednakuv case

            if(result == 0){
                result = Character.toUpperCase(f.getName().charAt(0)) -
                        Character.toUpperCase(s.getName().charAt(0));
                // charactarite sa intergeri i moga direktono
                //da gi izvadq
            }
            return  result;
        })
                .forEach(System.out::println);
        //compare by age
        byAge.stream().sorted(Comparator.comparing(Person::getAge))
                .forEach(System.out::println);
    }
}


package StrategyPattern;

public class Person {
    private String name;
    private int age;

    public Person(String name, int age){
        this.name = name;
        this.age = age;
    }
    public String getName(){
        return this.name;
    }
    public int getAge(){
        return this.age;
    }

    @Override
    public String toString(){
        return this.name + " " + this.age;
    }
}


 */

/* drugo reshenie

package StrategyPattern;

import java.awt.desktop.SystemSleepEvent;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = Integer.parseInt(scanner.nextLine());

        List<Person> byName = new ArrayList<>();
        List<Person> byAge = new ArrayList<>();
        while (n-- > 0){
            //vzimam celiq red i go vrushtam kato person
            //imam potok ot stingove koito trqbva da se mapne
            String[] tokens = scanner.nextLine().split("\\s+");
            String name = tokens[0];
            int age =Integer.parseInt(tokens[1]);
            Person person = new Person(name,age);
            //dobavqme personite v 2 lista i gi sortirame po razlichni pokazateli name i age

            byName.add(person);
            byAge.add(person);
        }                        //strategiqta e otgovornost na tozi obekt v CompareByName
        byName.stream().sorted(new CompareByName()).forEach(System.out::println);
        byAge.stream().sorted(new PersonComparatorByAge()).forEach(System.out::println);
    }
}


public class PersonComparatorByAge implements Comparator<Person> {
    @Override
    public int compare(Person first, Person second) {
        return first.getAge() - second.getAge();
    }
}


public class CompareByName implements Comparator<Person> {
    @Override
    public int compare(Person first, Person second){
        int result = first.getName().length() - second.getName().length();
        if(result == 0) {
            result = Character.toUpperCase(first.getName().charAt(0) -
                    Character.toUpperCase(second.getName().charAt(0)));
        }
        return result;
    }
}

 */

/*
package StrategyPattern;

import java.awt.desktop.SystemSleepEvent;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = Integer.parseInt(scanner.nextLine());

        Set<Person> byName = new TreeSet<>(new CompareByName());
        Set<Person> byAge = new TreeSet<>(new PersonComparatorByAge());
        while (n-- > 0){
            //vzimam celiq red i go vrushtam kato person
            //imam potok ot stingove koito trqbva da se mapne
            String[] tokens = scanner.nextLine().split("\\s+");
            String name = tokens[0];
            int age =Integer.parseInt(tokens[1]);
            Person person = new Person(name,age);
            //dobavqme personite v 2 lista i gi sortirame po razlichni pokazateli name i age

            byName.add(person);
            byAge.add(person);
        }                        //strategiqta e otgovornost na tozi obekt v CompareByName
        byName.forEach(System.out::println);
        byAge.forEach(System.out::println);
    }
}
 */