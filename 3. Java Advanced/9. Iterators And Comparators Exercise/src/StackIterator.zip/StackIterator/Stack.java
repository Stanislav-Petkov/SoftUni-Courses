package StackIterator;

import java.util.Iterator;
import java.util.function.Consumer;

public class Stack<E> implements Iterable<E> {

    private Node<E> top;// v Node moje da durjim razlichni tipove i integer

    @Override
    public Iterator<E> iterator() { //tova e metoda koito Stack<E> iziskva da bude suzdaden za da vrushta iteratora ot vutreshniq klas
        return new StackIterator<E>(this.top);

    }
    private static class StackIterator<E> implements Iterator<E> {

        // sled kato e statichen nqma dostup do klasa v koito e definiran
        //za da mojem da hodim po strukturata trqbva da znae top elementta koito shte si go prisvoi v nova promentliva
        private Node<E> current;    // trukva ot top i se mesti
        StackIterator(Node<E> current) {
            this.current = current;
        }

        @Override
        public boolean hasNext() {
            return this.current != null; // kogato prisvoq null na current znachi sum minal prez vsichki i natatuk nqma
        }

        @Override
        public E next() {
            E element = this.current.element;

            //premestvam current
            this.current = this.current.prev; // hodi nadolu
            return element;
        }
    }
    @Override
    public void forEach(Consumer<? super E> action) {
//        //vzimam tekushtiq element
//        Iterator<E> iterator = this.iterator();
//        while (iterator.hasNext()){
//            action.accept(iterator.next());
//        }
        for(E e : this){ // vzima element i acceptva deistvieto za nego
            action.accept(e);
        }
    }


private static class Node<E> {
    E element;
    Node<E> prev;

    Node(E element) {
        this.element = element;
    }

}

    public Stack() {
    }

    public void push(E element) {
        Node<E> newNode = new Node<>(element);
        newNode.prev = this.top;
        this.top = newNode;
    }

    public E pop() {
        if (this.top == null) {
            throw new IndexOutOfBoundsException("No elements");
        }
        E element = this.top.element;
        //razkacham tekshtiq top da stane predhodniq
        Node<E> prev = this.top.prev;
        this.top.prev = null; //kazvame che na top elementa negovata prev referenciq e null
        this.top = prev;
        return element;
    }


    //trabva da znaem predishni element na stack
}


/*
package StackIterator;

public class Stack<E> {

    private Node<E> top;// v Node moje da durjim razlichni tipove i integer

    private static class Node<E>{
        E element;
        Node<E> prev;

        Node(E element){
            this.element = element;
        }
    }

    public Stack(){
    }

    public void push(E element){
        Node<E> newNode = new Node<>(element);
        newNode.prev = this.top;
        this.top = newNode;
    }

    public E pop(){
        if(this.top == null){
            return null;
        }
        E element = this.top.element;
        //razkacham tekshtiq top da stane predhodniq
        Node<E> prev = this.top.prev;
        this.top.prev = null; //kazvame che na top elementa negovata prev referenciq e null
        this.top = prev;
        return element;
    }


    //trabva da znaem predishni element na stack
}




 */















