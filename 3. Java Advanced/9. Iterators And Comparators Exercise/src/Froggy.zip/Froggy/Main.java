package Froggy;

import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Integer[] stones = Arrays.stream(scanner.nextLine().split(", "))
                .map(Integer::parseInt)
                .toArray(Integer[]::new);

        Lake lake = new Lake(stones);
        StringBuilder builder = new StringBuilder();
        for(Integer integer : lake){
            builder.append(integer).append(", ");
        }
        System.out.println(builder.toString().substring(0, builder.toString().lastIndexOf(", ")));
//        for (int i = 0; i < stones.length; i += 2) {
//            System.out.print(stones[i] + " ");
//            if(stones.length % 2 == 0 && i == stones.length - 2){
//                i = -1;
//            }else if(i == stones.length - 1){
//                i = -1;
//            }
//        }
        
    }
}
