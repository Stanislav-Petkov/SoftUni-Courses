package ReverseIterator;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class ListlyIterator implements Iterable<String> {
    private List<String> elements;
    private int index;

    public ListlyIterator(String... values) {
        this.elements = Arrays.asList(values);
        this.index = 0;
    }


    public String next() {
        return this.elements.get(index++);
    }

    public boolean move() {
        if (!this.hasNext()) {
            return false; // ne moje da se mesti natatuk ako indeksa sochi posledniq element
        }
        this.index++;
        return true;
        //return this.index <= this.elements.size() - 1;
        // ne trabva da stava raven na size zashtoto tam e sled kraq na lista
    }

    public boolean hasNext() {
        return this.index < this.elements.size() -1; // ako indeksa e po maluk ot predposledniq element na lista
        //ima na kude da se mesti s oshte 1 do posledniq i vrushta tru inache vrushta falsse
    }

    public String getCurrentElement() {
        if (this.elements.size() == 0) {
            throw new UnsupportedOperationException("Invalid Operation!");
        }
        return this.elements.get(this.index);
    }

    public static class ReverseIterator implements Iterator<String> {

        private int index = 0;
        private List<String> elements;

        ReverseIterator(int index, List<String> elements) {
            this.index = index;
            this.elements = elements;
        }

        @Override
        public boolean hasNext() {
            return this.index >= 0;//dokato indeksa e raven na 0
        }

        @Override
        public String next() {
            return this.elements.get(this.index--);
        }
    }

    public Iterator<String> reversed() {//kato nqkoi vika reversed() trugva ot posledni indes
        return new ReverseIterator(this.elements.size() - 1,this.elements);
    }//podavam posledniq indeks ot lista na iteratora

    //reversed() vrushta nova instanciq ot ReverseIterator() koito e iterator
    // i mu kazvame da zapochne otzad napred i da obhodi elementite

    @Override
    public Iterator<String> iterator() {
        return new Iterator<String>() {
            private int index = 0;

            @Override
            public boolean hasNext() {
                return this.index < elements.size();
            }

            @Override
            public String next() {
                return elements.get(this.index++);
            }
        };
    }
}

/*
moi opit
public class ListyIterator implements Iterator<String> {
    private String firstElement;
    private List<String> list;
    private int currentIndex;
    private int nextIndex;

    public ListyIterator(List<String> list){
        this.nextIndex = 0;
        this.list = list;
    }
    public boolean move(){
        if(this.next() != null) {
            this.nextIndex = nextIndex + 1;
            return true;
        }
        return false;
    }
    @Override
    public boolean hasNext() {
        return nextIndex < list.size();
    }

    @Override
    public String next() {
        String nextStr = list.get(nextIndex);
        nextIndex = nextIndex + 1;
        return nextStr;
    }

    public String print(){
        if(this.list.isEmpty()){
            return "Invalid Operation";
        }else {
            return list.get(this.currentIndex);
        }
    }
}
 */

/*
//pprintira vsichki elementi Create 1 2 3 4 5

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        //tozi masiv e samo za purvata create commanda
        String[] strings = Arrays.stream(scanner.nextLine().split("\\s+"))
                .skip(1) //propuska create commandata  vzima sledvashtite
                .map(e -> e.toString())
                .toArray(String[]::new);
        //kogato e primitiven masiv , toi ne extendva collection i ne mojem da polzvame
        //.collect     vikam toArray zashtoto na nego moje da mu kajem kakuv tip masiv iskame da mu slojim

        ListlyIterator listIterator = new ListlyIterator(strings);
        for (Iterator<String> iter = listIterator.iterator(); iter.hasNext();) {
           String next = iter.next();
            System.out.println(next);
        }

    }
}

package Collection;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class ListlyIterator implements Iterable<String> {
    private List<String> elements;
    private int index;

    public ListlyIterator(String... values){
        this.elements = Arrays.asList(values);
        this.index = 0;
    }


    public String next() {
        return this.elements.get(index++);
    }

    public boolean move(){
        if(!this.hasNext()){
            return false; // ne moje da se mesti natatuk ako indeksa sochi posledniq element
        }
        this.index++;
        return true;
        //return this.index <= this.elements.size() - 1;
        // ne trabva da stava raven na size zashtoto tam e sled kraq na lista
    }
    public boolean hasNext(){
        return this.index < this.elements.size(); // ako indeksa e po maluk ot predposledniq element na lista
        //ima na kude da se mesti s oshte 1 do posledniq i vrushta tru inache vrushta falsse
    }

    public String getCurrentElement(){
        if(this.elements.size() == 0){
            throw new UnsupportedOperationException("Invalid Operation!");
        }
        return this.elements.get(this.index);
    }

//    public void printAll(){
//        for (String s : this.elements) {
//            System.out.print(s + " ");
//        }
//        System.out.println();
//    }

    //preizpolzvam logika ot  getCurrentElement i hasNext i q vkarvam v nov obekt
    @Override
    public Iterator<String> iterator() {//vrushta obekta koito znae kak da iterira po stringovete
                return new Iterator<String>() { // anonimen klas ne se namira v otdelen sobstven obekt ili v otdelen fail
            //ako napisha tuk this to se otnasq samo za tozi klas Iterator i raboti mejdu negovite skobi

            private int index = 0; //imam i vunshen indeks no ne iskam da i promenqm strukturata s iteratora a samo da q obhodq
            //zatova se pravi vutreshen index
            @Override
            public boolean hasNext() {
                return this.index < elements.size(); // na tekushtiq indeks
            }

            @Override
            public String next() {
                return elements.get(this.index++);
            }//vrushta elementite vzima tekushtiq indek i go uvelichava
        };
    }
}

 */