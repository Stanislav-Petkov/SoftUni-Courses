package Collection;



import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        //tozi masiv e samo za purvata create commanda
        String[] strings = Arrays.stream(scanner.nextLine().split("\\s+"))
                .skip(1) //propuska create commandata  vzima sledvashtite
                .map(e -> e.toString())
                .toArray(String[]::new);
        //kogato e primitiven masiv , toi ne extendva collection i ne mojem da polzvame
        //.collect     vikam toArray zashtoto na nego moje da mu kajem kakuv tip masiv iskame da mu slojim

        ListlyIterator listIterator = new ListlyIterator(strings);

        String input = scanner.nextLine();
        while (!input.equals("END")) {

            switch (input) {
                case "Move":
                    System.out.println(listIterator.move());
                    break;
                case "HasNext":
                    System.out.println(listIterator.hasNext());
                    break;
                case "PrintAll":
                    listIterator.printAll();
                    break;
                case "Print":
                    try {
                        System.out.println(listIterator.getCurrenElement());
                    } catch (UnsupportedOperationException ex) {
                        System.out.println(ex.getMessage());
                    }
                    break;

            }

            input = scanner.nextLine();
        }
    }
}

/*
moi opit

        String line = scanner.nextLine();
        while (!line.equals("END")) {
            String[] tokens = line.split(" ");
            if ("Create".equals(tokens[0])) {
                List<String> newList = new ArrayList<>();
                for (int i = 1; i < tokens.length; i++) {
                    newList.add(tokens[i]);
                }
                ListlyIterator listIter = new ListlyIterator(newList);
                if ("Move".equals(tokens[0])) {
                    //ListyIterator listIter;
                    listIter.move();
                }
            }
//            } else if ("Print".equals(tokens[0])) {
//            } else if ("HasNext".equals(tokens[0])) {
//            } else if ("END".equals(tokens[0])) {
//                return;
//            }

            line = scanner.nextLine();
        }

    }

//    private static List<String> create(String... elements) {
//        List<String> newList = Arrays.asList(elements);
//        return newList;
//    }

 */