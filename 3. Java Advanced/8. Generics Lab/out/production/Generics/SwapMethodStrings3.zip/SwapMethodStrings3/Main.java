package SwapMethodStrings3;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = Integer.parseInt(scanner.nextLine());
        List<Box<String>> list = new ArrayList<>();
        while (n-- > 0){
            String line = scanner.nextLine();
            Box<String> box = new Box<>(line);
            list.add(box);
        }
        String[] arr = scanner.nextLine().split(" ");
        int first = Integer.parseInt(arr[0]);
        int second = Integer.parseInt(arr[1]);
        Box<String> temp = list.get(first);
        Box<String> first1 = list.get(second);
        list.set(first,first1);
        list.set(second,temp);
        for (int i = 0; i < list.size(); i++) {
            System.out.println(list.get(i));
        }

    }
}
