//package CustomListSorter8;
//
//public class CustomSort<T> extends ArrayList{
//    T element;
//    public CustomSort(){
//
//    }
//    //public static void sort(){
//
//    //}
//}
