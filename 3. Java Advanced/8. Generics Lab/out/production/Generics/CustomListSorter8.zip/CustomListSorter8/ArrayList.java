package CustomListSorter8;



import java.util.Arrays;
import java.util.Comparator;

public class ArrayList<E extends Comparable<E>> {
    private static final int INITIAL_CAPACITY = 4;
    private Object[] elements;
    private int size;

    public ArrayList() {
        this.elements = new Object[INITIAL_CAPACITY];
    }

    public void add(E element) {
        if (this.size == this.elements.length) {// ako size e kolko elementi ima v sebe si, znachi nqma na kude da dobava
            this.elements = grow();//logika za preorazmerqvane
        }
        this.elements[this.size++] = element;// v nachaloto size sochi kum 0 indeks na koito se dobavq element i sled tova se uvelichava
    }

    public boolean contains(Object element) {
        return this.indexOf(element) >= 0;// proverqva dali elementa ima indeks v masiva ako ima znachi se sudurja
    }

    public int indexOf(Object obj) {
        for (int i = 0; i < this.size; i++) {
            E at = this.getAt(i); // this.getAt(i); vrushta elementa zashtoto sum go castnal v get() metoda
            if (at.equals(obj)) {
                return i;
            }
        }
        return -1;
    }

    public void swap(int first, int second) {
        ensureIndex(first);
        ensureIndex(second);
        Object temp = this.elements[first];
        this.elements[first] = this.elements[second];
        this.elements[second] = temp;

    } // razmenqm 2 indeksa

    public int countGreaterThan(E element){
        int count =0 ;
        for (int i = 0; i < this.size ; i++) {
            if(this.get(i).compareTo(element) > 0){
                count++;
            }
        }
        return count;
    }

    @SuppressWarnings("unchecked")
    public E getMax(){
        return Arrays.stream(this.elements)
                .limit(this.size)// za da ne obhojda vsicki elementi ot preorazmereniq masiv a samo kolko ima
                .map(e -> (E) e)
                .max(Comparator.comparing(e -> e))
                .orElse(null);
    }

    @SuppressWarnings("unchecked")
    public E getMin(){
        return Arrays.stream(this.elements)
                .limit(this.size)
                .map(e -> (E) e) // castva elementite kum E
                .min(Comparator.comparing(e -> e))
                .orElse(null);
    }

    public E remove(int index){
        ensureIndex(index);
        E at = this.getAt(index);
        this.elements[index] = null;
        //trqbva da gi premestq sled kato mahna elementa
        // mestq tezi otdqsno s 1 nalqvo
        shift(index);
        this.size--;

        if(this.size == this.elements.length / 2) {//ako pazi 2 puti poveche elementa otkolkot ima v momenta
// se namalq
            this.elements = shrink();
        }
        return at;
    }

    private Object[] shrink(){
        return Arrays.copyOf(this.elements,this.elements.length / 2);
    }//namalq elementite 2 puti otkolkoto ima

    // mestq tezi otdqsno s 1 nalqvo
    private void shift(int index){
        for (int i = 0; i < this.size - 1; i++) { //stiga do predpolsledniq
            //zashtoto shte sa s 1 po malko
            this.elements[i] = this.elements[i + 1]; // s tazi operaciq dostupva i psledniq
        }
        this.elements[this.size - 1] = null;// posledni  stava null
        //zashtoto predhodnata kletka e vzela elementa ot posledniq
    }
    public E getAt(int index) {
        ensureIndex(index);//ako hvurli exception nadolu koda nqma da se izpulni i prikluchva metoda
        return this.get(index); // vika private metoda otdolu v koito ima type cast
    }

    @SuppressWarnings("unchecked")
    private E get(int index) {
        return (E) this.elements[index];//castvam edinichen element ot masiv i go vrshtam kato E , metoda e private za da se polzva samo v klasa
    }

    private void ensureIndex(int index) {
        if (index < 0 || index >= this.size) {
            throw new IndexOutOfBoundsException("Index out of bound for " + index +
                    " Array size of " + this.size);
        }
    }

    private Object[] grow() {
        return Arrays.copyOf(this.elements, this.elements.length * 2);// ako nqma mqsto v masiva kopira eleementita v nov 2 puti po golqm
        // is sled tova dobavq noe element v po golemiq  nov masiv
    }

    public void print(){
        for (int i = 0; i < this.size; i++) {
            System.out.println(this.elements[i].toString());
        }
    }
    public void sort() {
        //bubble sort ako tozi otdqsno e po maluk im razmenqme mestata
//murdash purviq element nadqsno dokato ne stignesh kraq
        for (int i = 0; i < this.size; i++) {
            E element = this.get(i);
            for (int j = 0; j < this.size - 1; j++) {
                if(element.compareTo(this.get(j)) < 0){
                    this.swap(i,j);
                }
            }
        }
    }



//    public void print(){
//        for (Object el : elements) {
//            System.out.println(el.toString());
//        }
//    }
}

/*
moje metoda contains i da e taka
 public boolean contains(Object element) {
        for (Object obj: this.elements) {
            if(obj.equals(element)){
                return true;
            }
        }
        return false;
    }


 */


/*
iizglejda tozi metod da raboti
 public E getMax(){
        E max = null;
        for (int i = 0; i < this.size - 1; i++){
                if(this.get(i).compareTo(this.get(i+1)) > 0){
                    max = this.get(i);
                }else {
                    max = this.get(i+1);
                }
            }
        return max;
    }



 public void print(){
        for (int i = 0; i < this.size; i++) {
            System.out.println(this.elements[i]);
        }
    }

 */





