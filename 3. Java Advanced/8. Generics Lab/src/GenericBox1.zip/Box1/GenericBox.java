package Box1;

public class GenericBox<T> {
    private T value;

    public GenericBox(T value){
        this.value = value;
    }

    @Override
    public String toString(){
        return value.getClass().getName() + ": " + value;
    }
}


/*

package Box1;

public class GenericBox<T> {
    T data;
    public GenericBox(T element){
        this.data = element;
    }

    public GenericBox() {

    }

    @Override
    public String toString(){
        return (String) data;
    }
}

 */

/*
package Box1;

public class GenericBox<T> {
    private Object value;

    public GenericBox(Object value){
        this.value = value;
    }

    @Override
    public String toString(){
        return value.getClass().getName() + ": " + value;
    }
}


 */