package GenericCountMethodStrings;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = Integer.parseInt(scanner.nextLine());
        List<Box<String>> boxes = new ArrayList<>();

        while (n-- > 0){
            String line = scanner.nextLine();
           Box<String> box = new Box<>(line);
           boxes.add(box);
        }
        String element = scanner.nextLine();
        int result = countGreaterElements(boxes,new Box<>(element));
        System.out.println(result);
    }
    private static <T extends Comparable<T>> int countGreaterElements(
            List<Box<T>> boxes, Box<T> element) {// shtom znae che i dvete sa kutii znachi imat value
        //v klasa kato kazvame <T extends Comparable<T>>  tova oznacha che T tipa e sravnim
        int count = 0;
        for (Box<T> box : boxes) {
            
            if(box.compareTo(element) > 0){//sravnqvam direktno dvete kutii
                count++;
            }
        }
        return count;
    }

}

/*

package GenericCountMethodStrings;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = Integer.parseInt(scanner.nextLine());
        List<Box<String>> boxes = new ArrayList<>();

        while (n-- > 0){
            String line = scanner.nextLine();
           Box<String> box = new Box<>(line);
           boxes.add(box);
        }
        String element = scanner.nextLine();
        int result = countGreaterElements(boxes,new Box<>(element));
        System.out.println(result);
    }
    private static <T extends Comparable<T>> int countGreaterElements(
            List<Box<T>> boxes, Box<T> element) {// shtom znae che i dvete sa kutii znachi imat value
        //v klasa kato kazvame <T extends Comparable<T>>  tova oznacha che T tipa e sravnim
        int count = 0;
        for (Box<T> box : boxes) {

            if(box.getValue().compareTo(element.getValue()) > 0){//na kutiqta valueto sravni s na elementa valueto
                count++;
            }
        }
        return count;
    }

}

package GenericCountMethodStrings;

import java.util.List;

public class Box<T extends Comparable<T>> implements Comparable<T> {         //v klasa kato kazvame <T extends Comparable<T>>  tova oznacha che T tipa e sravnim
    T value;
    public Box(T value){
        this.value = value;
    }

    @Override
    public int compareTo(T other) {//sravnqva valueto s koet e inicializiral obekta s drugiq obekt
        return this.value.compareTo(other);
    }

    public T getValue() {
        return value;
    }
}













 */