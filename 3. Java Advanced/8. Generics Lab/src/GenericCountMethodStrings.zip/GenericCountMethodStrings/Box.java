package GenericCountMethodStrings;

import java.util.List;

//priravnqvam tipovete   implements Comparable<Box<T>>
// public int compareTo(Box<T> other)  za da raboti overrida na metoda compareTo trqbva parametura v metoda
//da e sushtiq kato v interfeisa koito implementira
public class Box<T extends Comparable<T>> implements Comparable<Box<T>> {         //v klasa kato kazvame <T extends Comparable<T>>  tova oznacha che T tipa e sravnim
    T value;
    public Box(T value){
        this.value = value;
    }

    @Override
    public int compareTo(Box<T> other) {//sravnqva valueto s koet e inicializiral obekta s drugiq obekt
        return this.value.compareTo(other.value);
    }

    public T getValue() {
        return value;
    }
}












