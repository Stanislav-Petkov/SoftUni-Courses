package scale;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scale<String> scale = new Scale<>("A","B");
        System.out.println(scale.getHeavier());

//        String a  = "b";
//        String b = "b";
//        System.out.println(a.compareTo(b));
    }
}

/*
v/*
public class Main {
    public static void main(String[] args) {
        Scale<Integer> scale = new Scale<Integer>(5,5);
        System.out.println(scale.getHeavier(5,5));

        String a  = "b";
        String b = "b";
        System.out.println(a.compareTo(b));
    }
}
 */