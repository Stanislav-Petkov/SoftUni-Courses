package scale;

import java.util.Scanner;

public class Scale<T extends Comparable<T>> { //iskam da mi dadesh klas koito moga da sravnqvam sus sebe si,
    //primer string koito moga da sravnqvam sus string
    //T moje da e vseki edin klas v java, napisan ot nas, napisan ot nqkoi drug ili klas koito shte bude napisan
    private T left;
    private T right;

    public Scale(T left, T right){
        this.left = left;
        this.right = right;
    }

    public T getHeavier(){
        if(this.left.equals(this.right)){
            return null;
        }

        if(left.compareTo(right) < 0) { // veche kato napisha left. i imam dostup do edinstveniq metod v Comparable
            return right;
        }
            return left;
    }
}

/*
vrushta po golqmoto
public class Main {
    public static void main(String[] args) {
        Scale<Integer> scale = new Scale<Integer>(59,10);
        System.out.println(scale.getHeavier());

        trbva da sa ot edin  susht tip Scale<Integer> obektite koito se sravnqvat
 */
