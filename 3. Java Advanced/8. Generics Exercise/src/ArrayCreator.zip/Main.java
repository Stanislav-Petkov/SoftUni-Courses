import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        String[] array = ArrayCreator.create(5, "alice");
        String[] array2 = ArrayCreator.create(String.class, 5, "Bob");
        //String[] array = ArrayCreator.create(5, "alice"); ne raboti
        for (int i = 0; i < array2.length; i++) {
            System.out.println(array2[i]);
        }

    }
}

/*
       Jarrable<Integer> jarrable = new Jar<>();
        List<Integer> list = new LinkedList<>();
        list.add(15);
        list.add("Alice");
        list.add(12);
        printList(list);
    }
    private static void printList(List<Integer> list){ // davam obekt koito otgovarq na kontrakta na List
        for (Integer jarrable1 : list) {
            System.out.println(jarrable1);
        }
    }

 */
/*
// stringJar.add(1) ne moga da dobavq ne string  public class StringJar extends Jar<String> {


 */

/*

public class Main {
    public static void main(String[] args)  {

        StringJar stringJar = new StringJar();
        stringJar.add("ele");
        stringJar.add("ele");
        System.out.println(stringJar.remove());
        stringJar.remove(); // stringJar.add(1) ne moga da dobavq ne string  public class StringJar extends Jar<String> {
        System.out.println(stringJar.toString());
    }
}
 */

/*

        GenericArrayListWithPrintMe<Integer> ar = new GenericArrayListWithPrintMe();
        ar.add(1);
        ar.add(3);
        ar.add(3);
        ar.printMe();

 */

/*
  public static void main(String[] args)  {
        Jarrable<Integer> jarrable = new Jar<>();
        List<Integer> list = new LinkedList<>(); // klasa implementira interfeisa
// ne pisha LinkedList <Integer> list zashtoto ako imam mnogo metodi kato dolniq
       // private static void printList(List<Integer> list)      shte trqbva na vseki metod da smenqm tipa  na obekta
        // ako se naloji promqna
        list.add(15);
        list.add(16);
        list.add(12);
        printList(list);
    }
    private static void printList(List<Integer> list){ // davam obekt koito otgovarq na kontrakta na List
        for (Integer jarrable1 : list) {
            System.out.println(jarrable1);
        }
    }
 */