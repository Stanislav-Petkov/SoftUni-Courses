import java.lang.reflect.Array;

public class ArrayCreator {
    public static <T> T[] create(int length, T item) {//shablonen tip samo za metoda
        //T[] array = (T[]) new Object[length];  //shablonnite tipove rabotqt samo povreme na kompilaciq na koda
        //kogato sum v metoda ne moga da instanciram masiv ot tozi tip  T[] array = new T[length];
        //T[] e masiv ot objecti a ne e masiv ot T zashtoto kazvam new Object
        //T si gubi tipa po vreme na kompilaciq

        T[] array = (T[]) Array.newInstance(item.getClass(), length); // raboti s reflection
        //mojem da rabotim s takiva masivi no ne trqbva da gi vrushtame kum klienta ni
        // ne trqbva da vrushtame masiv ot tip T public static <T> T[]
        for (int i = 0; i < array.length; i++) {
            array[i] = item;
        }
        return array;
    }


    //Class<T> clazz class ot tip e T e klasa koito sum podal v maina
    public static <T> T[] create(Class<T> clazz, int length, T item) {
        T[] array = (T[]) Array.newInstance(clazz, length);
        for (int i = 0; i < array.length; i++) {
            array[i] = item;
        }
        return array;
    }

}

/*
import java.lang.reflect.Array;

public class ArrayCreator {
    public static <T> T[] create(int length, T item){//shablonen tip samo za metoda
        //T[] array = (T[]) new Object[length];  //shablonnite tipove rabotqt samo povreme na kompilaciq na koda
        //kogato sum v metoda ne moga da instanciram masiv ot tozi tip  T[] array = new T[length];
        //T[] e masiv ot objecti a ne e masiv ot T zashtoto kazvam new Object
        //T si gubi tipa po vreme na kompilaciq

        T[] array = (T[]) Array.newInstance(item.getClass(), length); // raboti s reflection
        for (int i = 0; i < array.length; i++) {
            array[i] = item;
        }
        return array;
    }
}

public class Main {
    public static void main(String[] args) {
        Object[] array = ArrayCreator.create(5, "alice");
        //String[] array = ArrayCreator.create(5, "alice"); ne raboti
        for (int i = 0; i < array.length; i++) {
            System.out.println(array[i]);
        }

    }
}


 */
